import React, { useState } from 'react';
import {
  Users2,
  Shield,
  KeyRound,
  UserCheck,
  UserX,
  Mail,
  Calendar,
  CheckCircle2,
  Lock,
  AlertTriangle,
} from 'lucide-react';
import { UserRole, UserProfile } from '../types';
import { useAuth } from '../context/AuthContext';

export const UserManagement: React.FC = () => {
  const { user, profile, role, isAdmin } = useAuth();

  // Active enterprise users
  const [userList, setUserList] = useState<UserProfile[]>([
    {
      uid: user?.uid || 'usr-admin-bootstrap',
      email: user?.email || 'yadavlathish6@gmail.com',
      displayName: user?.displayName || 'Lead Security Architect (You)',
      role: 'ADMIN',
      createdAt: '2026-11-01T08:00:00Z',
      updatedAt: '2026-11-06T00:15:00Z',
    },
    {
      uid: 'usr-analyst-1',
      email: 'analyst.tier2@phishguard.internal',
      displayName: 'Marcus Thorne',
      role: 'SECURITY_ANALYST',
      createdAt: '2026-10-15T12:30:00Z',
      updatedAt: '2026-11-04T16:20:00Z',
    },
    {
      uid: 'usr-viewer-1',
      email: 'auditor.compliance@phishguard.internal',
      displayName: 'Elena Rostova',
      role: 'VIEWER',
      createdAt: '2026-10-20T09:15:00Z',
      updatedAt: '2026-11-01T11:00:00Z',
    },
  ]);

  const permissionsMatrix = [
    { action: 'Execute Real-time Email Scans', admin: true, analyst: true, viewer: true },
    { action: 'Analyze URLs & Lookalike Domains', admin: true, analyst: true, viewer: true },
    { action: 'View Threat Explanation & AI Telemetry', admin: true, analyst: true, viewer: true },
    { action: 'Approve / Reject Quarantine Requests', admin: true, analyst: true, viewer: false },
    { action: 'Register & Modify Global Threat IOCs', admin: true, analyst: true, viewer: false },
    { action: 'Manage User Roles & Permissions', admin: true, analyst: false, viewer: false },
    { action: 'Modify Integration API Keys & Settings', admin: true, analyst: false, viewer: false },
  ];

  const handleRoleChange = (uid: string, newRole: UserRole) => {
    if (!isAdmin) {
      alert('Only administrators can reassign user roles.');
      return;
    }
    setUserList((prev) =>
      prev.map((u) => (u.uid === uid ? { ...u, role: newRole, updatedAt: new Date().toISOString() } : u))
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-900">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight font-mono flex items-center gap-2">
            <Users2 className="w-5 h-5 text-cyan-400" />
            Role-Based Access Control (RBAC) & Identity Management
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Zero-Trust credential management: ADMIN, SECURITY_ANALYST, and VIEWER privilege tiering.
          </p>
        </div>
      </div>

      {/* User Roster */}
      <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-4">
        <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider">
          Authorized Security Personnel
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-500 text-[11px]">
                <th className="pb-3 font-medium">OFFICER / EMAIL</th>
                <th className="pb-3 font-medium">ASSIGNED ROLE</th>
                <th className="pb-3 font-medium">PROVISIONED AT</th>
                <th className="pb-3 font-medium">STATUS</th>
                <th className="pb-3 font-medium text-right">ROLE ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {userList.map((u) => (
                <tr key={u.uid} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 font-sans">
                    <div className="font-semibold text-white text-xs">{u.displayName}</div>
                    <div className="text-[11px] text-slate-400 font-mono">{u.email}</div>
                  </td>
                  <td className="py-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        u.role === 'ADMIN'
                          ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                          : u.role === 'SECURITY_ANALYST'
                          ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {u.role}
                    </span>
                  </td>
                  <td className="py-3 text-slate-500 text-[11px]">
                    {new Date(u.createdAt).toLocaleDateString()}
                  </td>
                  <td className="py-3">
                    <span className="flex items-center gap-1.5 text-emerald-400 text-[11px]">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                      ACTIVE
                    </span>
                  </td>
                  <td className="py-3 text-right">
                    <select
                      value={u.role}
                      onChange={(e) => handleRoleChange(u.uid, e.target.value as UserRole)}
                      disabled={!isAdmin}
                      className="bg-slate-950 border border-slate-800 text-slate-300 text-xs rounded px-2 py-1 outline-none disabled:opacity-50"
                    >
                      <option value="ADMIN">ADMIN</option>
                      <option value="SECURITY_ANALYST">SECURITY_ANALYST</option>
                      <option value="VIEWER">VIEWER</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Permissions Matrix */}
      <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-4">
        <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
          <KeyRound className="w-4 h-4 text-cyan-400" />
          Role Permissions Matrix (ABAC Architecture)
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-500 text-[11px]">
                <th className="pb-3 font-medium">CAPABILITY / WORKFLOW</th>
                <th className="pb-3 font-medium text-center">ADMIN</th>
                <th className="pb-3 font-medium text-center">SECURITY_ANALYST</th>
                <th className="pb-3 font-medium text-center">VIEWER</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {permissionsMatrix.map((p, idx) => (
                <tr key={idx} className="hover:bg-slate-800/40">
                  <td className="py-2.5 text-slate-300 font-sans text-xs">{p.action}</td>
                  <td className="py-2.5 text-center">
                    {p.admin ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mx-auto" />
                    ) : (
                      <Lock className="w-3.5 h-3.5 text-slate-600 mx-auto" />
                    )}
                  </td>
                  <td className="py-2.5 text-center">
                    {p.analyst ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mx-auto" />
                    ) : (
                      <Lock className="w-3.5 h-3.5 text-slate-600 mx-auto" />
                    )}
                  </td>
                  <td className="py-2.5 text-center">
                    {p.viewer ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mx-auto" />
                    ) : (
                      <Lock className="w-3.5 h-3.5 text-slate-600 mx-auto" />
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
