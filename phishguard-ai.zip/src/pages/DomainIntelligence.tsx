import React, { useState } from 'react';
import {
  Globe2,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Server,
  Calendar,
  Lock,
  Search,
  Loader2,
  CheckCircle2,
  ExternalLink,
  Layers,
} from 'lucide-react';
import { DomainAnalysisResult } from '../types';
import { useAuth } from '../context/AuthContext';
import { logSecurityAudit } from '../services/dataService';

export const DomainIntelligence: React.FC = () => {
  const { user } = useAuth();
  const [domainInput, setDomainInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<DomainAnalysisResult | null>(null);

  const sampleDomains = [
    'micros0ft-account-verify.xyz',
    'paypal.com.account-update.info',
    'google.com',
    'chase-banking-support.top',
  ];

  const handleLookup = async (targetDomain?: string) => {
    const domain = (targetDomain || domainInput).trim();
    if (!domain) {
      setError('Please provide a domain name to evaluate.');
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('/api/v1/domains/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ domain }),
      });

      if (!response.ok) {
        throw new Error('Domain lookup failed: ' + response.statusText);
      }

      const data: DomainAnalysisResult = await response.json();
      setResult(data);

      await logSecurityAudit(
        user?.uid || 'analyst',
        user?.email || 'analyst@phishguard.internal',
        'DOMAIN_INTELLIGENCE_LOOKUP',
        `Evaluated domain ${domain} - Classification: ${data.classification} (Risk: ${data.riskScore}/100)`
      );
    } catch (err: any) {
      setError(err.message || 'Failed to analyze domain.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-900">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight font-mono flex items-center gap-2">
            <Globe2 className="w-5 h-5 text-cyan-400" />
            Domain Intelligence & Typosquatting Analyzer
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Resolve authoritative DNS records, homograph brand impersonation, SPF/DMARC coverage, and domain reputation.
          </p>
        </div>
      </div>

      {/* Input */}
      <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
            <input
              type="text"
              value={domainInput}
              onChange={(e) => setDomainInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleLookup()}
              placeholder="e.g. micros0ft-account-verify.xyz or paypal.com"
              className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg pl-9 pr-3 py-2.5 text-xs text-slate-200 placeholder-slate-600 font-mono outline-none"
            />
          </div>
          <button
            onClick={() => handleLookup()}
            disabled={loading || !domainInput.trim()}
            className="px-6 py-2.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-50 text-slate-950 font-bold text-xs tracking-wide shadow-lg shadow-cyan-500/20 transition-all flex items-center justify-center gap-2 active:scale-98"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Querying DNS & Brand Lexicons...
              </>
            ) : (
              <>
                <Globe2 className="w-4 h-4" />
                Lookup Domain Intel
              </>
            )}
          </button>
        </div>

        {/* Quick sample chips */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="text-slate-500 font-mono text-[11px]">Quick Tests:</span>
          {sampleDomains.map((d, i) => (
            <button
              key={i}
              onClick={() => {
                setDomainInput(d);
                handleLookup(d);
              }}
              className="px-2.5 py-1 rounded bg-slate-950 hover:bg-slate-800 text-slate-300 font-mono text-[11px] border border-slate-800 transition-colors"
            >
              {d}
            </button>
          ))}
        </div>

        {error && (
          <div className="p-3 rounded-lg bg-red-950/40 border border-red-900/50 text-red-300 text-xs">
            {error}
          </div>
        )}
      </div>

      {/* Results */}
      {result && (
        <div className="space-y-5 animate-in fade-in duration-300">
          {/* Top Banner */}
          <div
            className={`p-5 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
              result.riskScore >= 70
                ? 'bg-red-950/30 border-red-500/40 text-red-300'
                : result.riskScore >= 35
                ? 'bg-amber-950/30 border-amber-500/40 text-amber-300'
                : 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300'
            }`}
          >
            <div>
              <div className="text-[10px] font-mono tracking-wider uppercase opacity-80">
                DOMAIN REPUTATION ASSESSMENT
              </div>
              <h2 className="text-xl font-bold font-mono tracking-tight text-white flex items-center gap-2 mt-0.5">
                {result.domain}
              </h2>
              <div className="text-xs opacity-90 mt-1">{result.classification}</div>
            </div>

            <div className="flex items-center gap-6 font-mono">
              <div className="text-right">
                <div className="text-[10px] opacity-70">REPUTATION SCORE</div>
                <div className="text-xl font-bold">{result.reputationScore}/100</div>
              </div>
              <div className="text-right">
                <div className="text-[10px] opacity-70">THREAT RISK</div>
                <div className="text-xl font-black">{result.riskScore}/100</div>
              </div>
            </div>
          </div>

          {/* Lookalike & Homoglyph Assessment */}
          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
            <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-cyan-400" />
              Brand Spoofing & Homograph Analysis
            </h3>
            {result.lookalikeAnalysis.isSpoofAttempt ? (
              <div className="p-3 rounded-lg bg-red-950/40 border border-red-900/50 text-red-300 text-xs flex items-start gap-2.5 font-mono">
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold">SUSPECTED BRAND IMPERSONATION DETECTED</div>
                  <div className="text-slate-300 mt-1">{result.lookalikeAnalysis.notes}</div>
                  {result.lookalikeAnalysis.targetBrand && (
                    <div className="mt-1 text-cyan-300">
                      Target Brand: <span className="font-bold">{result.lookalikeAnalysis.targetBrand}</span>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="p-3 rounded-lg bg-emerald-950/20 border border-emerald-900/30 text-emerald-300 text-xs flex items-center gap-2 font-mono">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                No direct visual homograph or brand impersonation patterns flagged.
              </div>
            )}
          </div>

          {/* DNS Records Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* A & MX Records */}
            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-3">
              <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Server className="w-4 h-4 text-cyan-400" />
                A & MX Mail Routing Records
              </h3>
              <div className="space-y-2 text-xs font-mono">
                <div>
                  <span className="text-slate-500 block mb-1">A Records (Host IPs):</span>
                  {result.dns.aRecords.map((ip, idx) => (
                    <div key={idx} className="p-2 rounded bg-slate-950 text-slate-200 border border-slate-850">
                      {ip}
                    </div>
                  ))}
                </div>
                <div>
                  <span className="text-slate-500 block mb-1">MX Records (Mail Exchangers):</span>
                  {result.dns.mxRecords.map((mx, idx) => (
                    <div key={idx} className="p-2 rounded bg-slate-950 text-slate-200 border border-slate-850 flex justify-between">
                      <span>{mx.host}</span>
                      <span className="text-slate-500">Pri: {mx.priority}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* SPF & DMARC Records */}
            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-3">
              <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Lock className="w-4 h-4 text-cyan-400" />
                Email Security Policy (SPF & DMARC)
              </h3>
              <div className="space-y-2 text-xs font-mono">
                <div>
                  <span className="text-slate-500 block mb-1">SPF Policy Record (TXT):</span>
                  <div className="p-2 rounded bg-slate-950 text-slate-200 border border-slate-850 break-all select-all">
                    {result.dns.spfRecord}
                  </div>
                </div>
                <div>
                  <span className="text-slate-500 block mb-1">DMARC Policy Record (_dmarc):</span>
                  <div className="p-2 rounded bg-slate-950 text-slate-200 border border-slate-850 break-all select-all">
                    {result.dns.dmarcRecord}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
