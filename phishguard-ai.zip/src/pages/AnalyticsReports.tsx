import React, { useState } from 'react';
import {
  BarChart3,
  Download,
  Calendar,
  PieChart as PieIcon,
  TrendingUp,
  FileCheck,
  Shield,
  Activity,
  Layers,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from 'recharts';
import { ScanRecord } from '../types';

interface AnalyticsReportsProps {
  scans: ScanRecord[];
}

export const AnalyticsReports: React.FC<AnalyticsReportsProps> = ({ scans }) => {
  const [reportFormat, setReportFormat] = useState<'summary' | 'executive' | 'full'>('summary');

  const totalScans = scans.length;
  const phishingScans = scans.filter((s) => s.classification === 'Phishing');
  const suspiciousScans = scans.filter((s) => s.classification === 'Suspicious');
  const safeScans = scans.filter((s) => s.classification === 'Safe');

  const detectionRate = totalScans > 0 ? Math.round(((phishingScans.length + suspiciousScans.length) / totalScans) * 100) : 0;
  const avgRiskScore = totalScans > 0 ? Math.round(scans.reduce((a, b) => a + b.riskScore, 0) / totalScans) : 0;

  // Breakdown by Scan Type
  const typeCounts: Record<string, number> = {};
  scans.forEach((s) => {
    typeCounts[s.scanType] = (typeCounts[s.scanType] || 0) + 1;
  });
  const typeData = Object.entries(typeCounts).map(([name, count]) => ({
    name: name.toUpperCase(),
    count,
  }));

  // Threat Vector breakdown
  const vectorCounts: Record<string, number> = {};
  scans.forEach((s) => {
    s.tactics?.forEach((t) => {
      vectorCounts[t] = (vectorCounts[t] || 0) + 1;
    });
    s.indicators?.forEach((ind) => {
      vectorCounts[ind.category] = (vectorCounts[ind.category] || 0) + 1;
    });
  });
  const vectorData = Object.entries(vectorCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([vector, frequency]) => ({ vector, frequency }));

  // Trend line timeline
  const trendMap: Record<string, { date: string; risk: number; count: number }> = {};
  scans.forEach((s) => {
    const d = new Date(s.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric' });
    if (!trendMap[d]) {
      trendMap[d] = { date: d, risk: s.riskScore, count: 1 };
    } else {
      trendMap[d].risk = Math.round((trendMap[d].risk + s.riskScore) / 2);
      trendMap[d].count += 1;
    }
  });
  const trendData = Object.values(trendMap).slice(-7);

  const handleDownloadReport = () => {
    const reportText = `PHISHGUARD AI - EXECUTIVE THREAT ANALYTICS REPORT
Generated: ${new Date().toUTCString()}
Classification: CONFIDENTIAL / SOC INTERNAL USE ONLY

EXECUTIVE SUMMARY
-----------------
Total Evaluated Assets: ${totalScans}
Active Phishing Detections: ${phishingScans.length}
Suspicious Anomalies: ${suspiciousScans.length}
Clean Communications: ${safeScans.length}
Overall Threat Detection Ratio: ${detectionRate}%
Average Fleet Risk Score: ${avgRiskScore}/100

TOP OBSERVED THREAT VECTORS:
${vectorData.map((v, i) => `${i + 1}. ${v.vector} (${v.frequency} detections)`).join('\n')}

RECOMMENDED ENTERPRISE POSTURE ACTIONS:
1. Enforce DMARC "p=reject" policy across all inbound and outbound email domains.
2. Maintain active zero-day domain lookalike blocking on perimeter firewalls.
3. Conduct quarterly credential harvesting phishing simulations for finance and executive teams.
`;

    const blob = new Blob([reportText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `phishguard-executive-report-${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-900">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight font-mono flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-cyan-400" />
            Security Analytics & Executive Reporting
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Aggregate vulnerability trends, attack vector frequency, and board-ready security posture documentation.
          </p>
        </div>

        <button
          onClick={handleDownloadReport}
          className="px-4 py-2 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-md transition-all flex items-center gap-2 active:scale-95 font-mono"
        >
          <Download className="w-4 h-4" />
          Export Executive Report
        </button>
      </div>

      {/* KPI Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono">
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <div className="text-[10px] text-slate-500 uppercase">Detection Efficacy</div>
          <div className="text-2xl font-black text-cyan-400 mt-1">{detectionRate}%</div>
          <div className="text-[10px] text-slate-400 mt-1">AI Classification rate</div>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <div className="text-[10px] text-slate-500 uppercase">Avg Threat Risk</div>
          <div className="text-2xl font-black text-amber-400 mt-1">{avgRiskScore}/100</div>
          <div className="text-[10px] text-slate-400 mt-1">Weighted composite score</div>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <div className="text-[10px] text-slate-500 uppercase">High/Critical Payloads</div>
          <div className="text-2xl font-black text-red-400 mt-1">{phishingScans.length}</div>
          <div className="text-[10px] text-slate-400 mt-1">Isolations logged</div>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <div className="text-[10px] text-slate-500 uppercase">Total Assets Audited</div>
          <div className="text-2xl font-black text-white mt-1">{totalScans}</div>
          <div className="text-[10px] text-slate-400 mt-1">In Firestore database</div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Threat Vectors Chart */}
        <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col">
          <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider mb-4 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-cyan-400" />
            Top Phishing Tactics & Vectors
          </h3>
          <div className="h-64 w-full">
            {vectorData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={vectorData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis type="number" stroke="#64748b" fontSize={11} allowDecimals={false} />
                  <YAxis
                    dataKey="vector"
                    type="category"
                    stroke="#94a3b8"
                    fontSize={10}
                    width={130}
                    tickFormatter={(v) => (v.length > 18 ? v.substring(0, 16) + '..' : v)}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#070b14',
                      borderColor: '#1e293b',
                      borderRadius: '8px',
                      fontSize: '12px',
                    }}
                  />
                  <Bar dataKey="frequency" fill="#06b6d4" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-slate-500 font-mono">
                No vector metrics recorded.
              </div>
            )}
          </div>
        </div>

        {/* Scan Type Breakdown */}
        <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col">
          <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider mb-4 flex items-center gap-2">
            <Layers className="w-4 h-4 text-cyan-400" />
            Volume Distribution by Scan Target
          </h3>
          <div className="h-64 w-full">
            {typeData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={typeData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="name" stroke="#64748b" fontSize={11} />
                  <YAxis stroke="#64748b" fontSize={11} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#070b14',
                      borderColor: '#1e293b',
                      borderRadius: '8px',
                      fontSize: '12px',
                    }}
                  />
                  <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-slate-500 font-mono">
                No telemetry available.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
