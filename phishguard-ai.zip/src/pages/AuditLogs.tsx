import React, { useState } from 'react';
import {
  ScrollText,
  Search,
  ShieldCheck,
  Download,
  Clock,
  User,
  Activity,
  Terminal,
} from 'lucide-react';
import { AuditLogEntry } from '../types';

interface AuditLogsProps {
  logs: AuditLogEntry[];
}

export const AuditLogs: React.FC<AuditLogsProps> = ({ logs }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredLogs = logs.filter(
    (l) =>
      l.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.details.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.userEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleExport = () => {
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      ['Log ID,Timestamp,Actor,Action,Target ID,Details']
        .concat(
          filteredLogs.map(
            (l) =>
              `${l.id},${l.timestamp},"${l.userEmail}",${l.action},"${l.targetId || ''}","${l.details.replace(
                /"/g,
                '""'
              )}"`
          )
        )
        .join('\n');
    const link = document.createElement('a');
    link.href = encodeURI(csvContent);
    link.download = `phishguard-audit-log-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-900">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight font-mono flex items-center gap-2">
            <ScrollText className="w-5 h-5 text-cyan-400" />
            Security Operations Audit Trail & Compliance Log
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Cryptographically sealed, append-only chronological record of analyst containment decisions, scans, and system operations.
          </p>
        </div>

        <button
          onClick={handleExport}
          className="px-3.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-mono transition-colors flex items-center gap-1.5"
        >
          <Download className="w-3.5 h-3.5" />
          Export Audit Trail
        </button>
      </div>

      {/* Search */}
      <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between gap-4">
        <div className="relative w-full max-w-md">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search audit trail by actor, action type, or event details..."
            className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-600 outline-none"
          />
        </div>
        <div className="text-xs font-mono text-slate-400">
          Showing <span className="text-cyan-400 font-bold">{filteredLogs.length}</span> events
        </div>
      </div>

      {/* Logs Table */}
      <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 overflow-x-auto">
        <table className="w-full text-left text-xs font-mono">
          <thead>
            <tr className="border-b border-slate-800 text-slate-500 text-[11px]">
              <th className="pb-3 font-medium">LOG ID</th>
              <th className="pb-3 font-medium">TIMESTAMP (UTC)</th>
              <th className="pb-3 font-medium">ACTOR (USER)</th>
              <th className="pb-3 font-medium">ACTION EVENT</th>
              <th className="pb-3 font-medium">TARGET / ENTITY</th>
              <th className="pb-3 font-medium">FORENSIC DETAILS</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {filteredLogs.map((log) => (
              <tr key={log.id} className="hover:bg-slate-800/40 transition-colors">
                <td className="py-3 text-[11px] text-slate-500">{log.id}</td>
                <td className="py-3 text-slate-400 text-[11px] whitespace-nowrap">
                  {new Date(log.timestamp).toLocaleString()}
                </td>
                <td className="py-3 text-cyan-300 font-semibold">{log.userEmail}</td>
                <td className="py-3">
                  <span className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-300 text-[10px] font-bold">
                    {log.action}
                  </span>
                </td>
                <td className="py-3 text-slate-400 text-[11px]">{log.targetId || 'SYSTEM'}</td>
                <td className="py-3 text-slate-300 max-w-md font-sans text-xs">{log.details}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
