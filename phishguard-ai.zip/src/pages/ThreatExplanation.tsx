import React, { useState, useEffect } from 'react';
import {
  BrainCircuit,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Sparkles,
  Link2,
  FileSearch,
  CheckCircle,
  HelpCircle,
  Send,
  Loader2,
  Copy,
  CheckCircle2,
} from 'lucide-react';
import { ScanRecord } from '../types';

interface ThreatExplanationProps {
  scans: ScanRecord[];
  selectedScanId?: string;
  onOpenChatWithScan: (scan: ScanRecord) => void;
}

export const ThreatExplanation: React.FC<ThreatExplanationProps> = ({
  scans,
  selectedScanId,
  onOpenChatWithScan,
}) => {
  const [activeScanId, setActiveScanId] = useState<string>(
    selectedScanId || scans[0]?.id || ''
  );
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (selectedScanId) {
      setActiveScanId(selectedScanId);
    } else if (!activeScanId && scans.length > 0) {
      setActiveScanId(scans[0].id);
    }
  }, [selectedScanId, scans]);

  const currentScan = scans.find((s) => s.id === activeScanId) || scans[0];

  const handleCopyReport = () => {
    if (!currentScan) return;
    const report = `PHISHGUARD AI INCIDENT FORENSIC REPORT
----------------------------------------
Scan ID: ${currentScan.id}
Target: ${currentScan.target}
Classification: ${currentScan.classification}
Risk Score: ${currentScan.riskScore}/100 (Confidence: ${currentScan.confidence}%)
Timestamp: ${currentScan.createdAt}

EXECUTIVE SUMMARY:
${currentScan.aiExplanation}

RECOMMENDED SOC ACTION:
${currentScan.recommendedAction}

KEY DETECTED INDICATORS:
${currentScan.evidenceSummary}
`;
    navigator.clipboard.writeText(report);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!currentScan) {
    return (
      <div className="p-8 rounded-xl bg-slate-900/30 border border-slate-800 text-center flex flex-col items-center justify-center min-h-[400px]">
        <FileSearch className="w-10 h-10 text-slate-500 mb-3" />
        <h3 className="text-sm font-semibold text-slate-300 font-mono">No Scan Telemetry Available</h3>
        <p className="text-xs text-slate-500 max-w-sm mt-1">
          Perform an email, URL, or header scan first to generate an explainable AI security report.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-900">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight font-mono flex items-center gap-2">
            <BrainCircuit className="w-5 h-5 text-cyan-400" />
            Explainable AI (XAI) Threat Reasoning Engine
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Grounded forensic justification: why the threat was flagged, feature weighting, and MITRE tactics.
          </p>
        </div>

        {/* Scan Selector Dropdown */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-mono text-slate-400">Select Incident:</label>
          <select
            value={currentScan.id}
            onChange={(e) => setActiveScanId(e.target.value)}
            className="bg-slate-900 border border-slate-800 text-slate-200 text-xs rounded-lg px-3 py-1.5 font-mono outline-none focus:border-cyan-500"
          >
            {scans.map((s) => (
              <option key={s.id} value={s.id}>
                [{s.classification.toUpperCase()}] {s.target?.slice(0, 35) || s.id}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Incident Card */}
      <div className="p-6 rounded-xl bg-slate-900/60 border border-slate-800 space-y-6">
        {/* Top Incident Banner */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-slate-500 mb-1">
              <span>INCIDENT ID: {currentScan.id}</span>
              <span>•</span>
              <span className="uppercase">{currentScan.scanType} SCAN</span>
              <span>•</span>
              <span>{new Date(currentScan.createdAt).toLocaleString()}</span>
            </div>
            <h2 className="text-lg font-bold text-white font-mono">{currentScan.target}</h2>
            {currentScan.sender && (
              <div className="text-xs text-slate-400 font-mono mt-1">
                From: <span className="text-slate-200">{currentScan.sender}</span>
              </div>
            )}
          </div>

          <div className="flex items-center gap-4">
            <div
              className={`px-4 py-2 rounded-xl border text-center font-mono ${
                currentScan.classification === 'Phishing'
                  ? 'bg-red-500/10 border-red-500/30 text-red-400'
                  : currentScan.classification === 'Suspicious'
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-400'
                  : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
              }`}
            >
              <div className="text-[10px] uppercase font-bold">VERDICT</div>
              <div className="text-lg font-black">{currentScan.classification}</div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center font-mono">
              <div className="text-[10px] text-slate-500 uppercase">RISK SCORE</div>
              <div className="text-lg font-bold text-cyan-400">{currentScan.riskScore}/100</div>
            </div>
          </div>
        </div>

        {/* 4 Pillars of Explainability Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* 1. Why the message was flagged */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-850 space-y-2">
            <h3 className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              1. Grounded Threat Reasoning
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              {currentScan.aiExplanation}
            </p>
          </div>

          {/* 2. Recommended Next Steps for Analyst */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-850 space-y-2">
            <h3 className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
              <CheckCircle className="w-3.5 h-3.5" />
              2. Recommended Containment Playbook
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              {currentScan.recommendedAction}
            </p>
            <div className="pt-2 text-[11px] text-slate-400">
              <span className="font-semibold text-slate-300">Next Action:</span> Initiate user mailbox purge, block associated IOCs, and notify the affected recipient.
            </div>
          </div>

          {/* 3. Indicators contributing to the score */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-850 space-y-2">
            <h3 className="text-xs font-mono font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5" />
              3. Detection Evidence Breakdown
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed font-mono">
              {currentScan.evidenceSummary || 'Standard baseline evaluation parameters applied.'}
            </p>
          </div>

          {/* 4. Observed Tactics & URLs */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-850 space-y-2">
            <h3 className="text-xs font-mono font-bold text-purple-400 uppercase tracking-wider flex items-center gap-1.5">
              <Link2 className="w-3.5 h-3.5" />
              4. Extracted Infrastructure & Tactics
            </h3>
            {currentScan.tactics && currentScan.tactics.length > 0 ? (
              <div className="flex flex-wrap gap-1.5">
                {currentScan.tactics.map((tac, idx) => (
                  <span
                    key={idx}
                    className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950/60 text-purple-300 border border-purple-800/40"
                  >
                    {tac}
                  </span>
                ))}
              </div>
            ) : (
              <div className="text-xs text-slate-500 font-mono">No special tactics tagged.</div>
            )}
            {currentScan.extractedUrls && currentScan.extractedUrls.length > 0 && (
              <div className="mt-2 text-xs font-mono text-cyan-300 break-all select-all">
                Embedded URL: {currentScan.extractedUrls[0]}
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyReport}
              className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors flex items-center gap-1.5"
            >
              {copied ? (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  Report Copied!
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  Copy Forensic Report
                </>
              )}
            </button>
          </div>

          <button
            onClick={() => onOpenChatWithScan(currentScan)}
            className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-md transition-all flex items-center gap-1.5 active:scale-95"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Investigate with Gemini Analyst Bot
          </button>
        </div>
      </div>
    </div>
  );
};
