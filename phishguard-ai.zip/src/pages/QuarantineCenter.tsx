import React, { useState } from 'react';
import {
  ArchiveRestore,
  ShieldCheck,
  ShieldAlert,
  CheckCircle2,
  XCircle,
  RotateCcw,
  AlertTriangle,
  FileText,
  User,
  Clock,
  Send,
  Loader2,
  Info,
  CheckSquare,
  Square,
  MinusSquare,
  Check,
  X,
} from 'lucide-react';
import { QuarantineRecord } from '../types';
import { updateQuarantineStatus, bulkUpdateQuarantineStatus, logSecurityAudit } from '../services/dataService';
import { useAuth } from '../context/AuthContext';

interface QuarantineCenterProps {
  quarantine: QuarantineRecord[];
  onRefresh: () => void;
}

export const QuarantineCenter: React.FC<QuarantineCenterProps> = ({ quarantine, onRefresh }) => {
  const { user, isAnalyst, isAdmin } = useAuth();
  const [selectedItem, setSelectedItem] = useState<QuarantineRecord | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [analystNotes, setAnalystNotes] = useState('');
  const [actionLoading, setActionLoading] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [bulkNotes, setBulkNotes] = useState('');

  const filteredItems = quarantine.filter((q) => {
    if (filterStatus === 'all') return true;
    return q.status === filterStatus;
  });

  const isAllSelected =
    filteredItems.length > 0 && filteredItems.every((item) => selectedIds.has(item.id));
  const isPartiallySelected =
    filteredItems.some((item) => selectedIds.has(item.id)) && !isAllSelected;

  const toggleSelectAll = () => {
    if (isAllSelected) {
      setSelectedIds(new Set());
    } else {
      const newSet = new Set(selectedIds);
      filteredItems.forEach((item) => newSet.add(item.id));
      setSelectedIds(newSet);
    }
  };

  const toggleSelectOne = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const newSet = new Set(selectedIds);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setSelectedIds(newSet);
  };

  const handleSingleAction = async (status: 'approved' | 'rejected' | 'released') => {
    if (!selectedItem) return;
    setActionLoading(true);
    try {
      await updateQuarantineStatus(
        selectedItem.id,
        status,
        user?.displayName || user?.email || 'SOC Analyst',
        analystNotes || undefined
      );

      await logSecurityAudit(
        user?.uid || 'analyst',
        user?.email || 'analyst@phishguard.internal',
        `QUARANTINE_${status.toUpperCase()}`,
        `Quarantine status set to ${status} for ${selectedItem.target}. Notes: ${analystNotes || 'None'}`,
        selectedItem.id
      );

      setSelectedItem(null);
      setAnalystNotes('');
      onRefresh();
    } catch (err: any) {
      console.error('Failed quarantine action:', err);
      alert('Action error: ' + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleBulkAction = async (status: 'approved' | 'rejected' | 'released') => {
    if (selectedIds.size === 0) return;
    setActionLoading(true);
    const idsToUpdate = Array.from(selectedIds);
    try {
      await bulkUpdateQuarantineStatus(
        idsToUpdate,
        status,
        user?.displayName || user?.email || 'SOC Analyst',
        bulkNotes || `Bulk ${status} by analyst`
      );

      await logSecurityAudit(
        user?.uid || 'analyst',
        user?.email || 'analyst@phishguard.internal',
        `QUARANTINE_BULK_${status.toUpperCase()}`,
        `Bulk updated ${idsToUpdate.length} quarantine items to "${status}". Notes: ${bulkNotes || 'None'}`
      );

      setSelectedIds(new Set());
      setBulkNotes('');
      if (selectedItem && selectedIds.has(selectedItem.id)) {
        setSelectedItem(null);
      }
      onRefresh();
    } catch (err: any) {
      console.error('Bulk quarantine action failed:', err);
      alert('Bulk action error: ' + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-900">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight font-mono flex items-center gap-2">
            <ArchiveRestore className="w-5 h-5 text-cyan-400" />
            Enterprise Quarantine Center & Analyst Approval Triage
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Simulated mailbox isolation queue. Review suspicious payloads, approve quarantine, or bulk-process requests in one click.
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2">
          {['all', 'pending', 'approved', 'rejected', 'released'].map((st) => (
            <button
              key={st}
              onClick={() => {
                setFilterStatus(st);
                setSelectedIds(new Set());
              }}
              className={`px-3 py-1 rounded-lg text-xs font-mono uppercase transition-all ${
                filterStatus === st
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Safety Compliance Callout */}
      <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-400 flex items-center gap-3">
        <Info className="w-4 h-4 text-cyan-400 shrink-0" />
        <span>
          <strong className="text-slate-200">Zero Auto-Deletion Policy:</strong> PhishGuard AI never automatically purges emails. All containment actions require explicit authorized security analyst review and dual-action confirmation.
        </span>
      </div>

      {/* Bulk Action Toolbar */}
      {selectedIds.size > 0 && (
        <div className="p-4 rounded-xl bg-gradient-to-r from-cyan-950/80 via-slate-900 to-blue-950/80 border border-cyan-500/40 shadow-[0_0_20px_rgba(6,182,212,0.15)] flex flex-col md:flex-row items-center justify-between gap-4 animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 font-mono font-bold text-xs">
              {selectedIds.size}
            </div>
            <div>
              <div className="text-xs font-mono font-bold text-white flex items-center gap-2">
                <span>{selectedIds.size} Quarantine Request{selectedIds.size > 1 ? 's' : ''} Selected</span>
              </div>
              <div className="text-[11px] text-slate-400">
                Execute batch containment action on selected tenant mailboxes
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto justify-end">
            <button
              onClick={() => handleBulkAction('approved')}
              disabled={actionLoading}
              className="px-3.5 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 disabled:opacity-40 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-red-600/20 transition-all active:scale-95"
            >
              {actionLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
              Approve All Selected ({selectedIds.size})
            </button>

            <button
              onClick={() => handleBulkAction('rejected')}
              disabled={actionLoading}
              className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 font-bold text-xs flex items-center gap-1.5 border border-slate-700 transition-all active:scale-95"
            >
              {actionLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <XCircle className="w-3.5 h-3.5" />}
              Reject Selected ({selectedIds.size})
            </button>

            <button
              onClick={() => handleBulkAction('released')}
              disabled={actionLoading}
              className="px-3.5 py-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 font-semibold text-xs flex items-center gap-1.5 transition-all active:scale-95"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Release Selected
            </button>

            <button
              onClick={() => setSelectedIds(new Set())}
              className="px-2.5 py-1.5 rounded-lg text-slate-400 hover:text-white text-xs font-mono transition-colors"
              title="Deselect All"
            >
              Deselect
            </button>
          </div>
        </div>
      )}

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* List of Quarantine items */}
        <div className="lg:col-span-7 space-y-3">
          {/* List Controls: Select All Checkbox Header */}
          {filteredItems.length > 0 && (
            <div className="px-3 py-2 rounded-lg bg-slate-900/40 border border-slate-800/80 flex items-center justify-between text-xs font-mono text-slate-400">
              <label className="flex items-center gap-2.5 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={isAllSelected}
                  ref={(input) => {
                    if (input) input.indeterminate = isPartiallySelected;
                  }}
                  onChange={toggleSelectAll}
                  className="w-4 h-4 rounded border-slate-700 bg-slate-950 text-cyan-500 accent-cyan-500 cursor-pointer"
                />
                <span className="font-semibold text-slate-300">
                  Select All ({filteredItems.length} items)
                </span>
              </label>

              <span className="text-[11px] text-slate-500">
                Filter: <span className="uppercase text-cyan-400 font-bold">{filterStatus}</span>
              </span>
            </div>
          )}

          {filteredItems.length > 0 ? (
            filteredItems.map((item) => {
              const isChecked = selectedIds.has(item.id);
              const isCardSelected = selectedItem?.id === item.id;
              return (
                <div
                  key={item.id}
                  onClick={() => {
                    setSelectedItem(item);
                    setAnalystNotes(item.analystNotes || '');
                  }}
                  className={`p-4 rounded-xl border transition-all cursor-pointer relative group ${
                    isChecked
                      ? 'bg-slate-900/90 border-cyan-500/60 shadow-[0_0_15px_rgba(6,182,212,0.12)]'
                      : isCardSelected
                      ? 'bg-slate-900 border-cyan-500/40'
                      : 'bg-slate-900/50 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="flex items-center gap-3">
                      {/* Bulk Selection Checkbox */}
                      <div
                        onClick={(e) => toggleSelectOne(item.id, e)}
                        className="pt-0.5"
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {}}
                          className="w-4 h-4 rounded border-slate-700 bg-slate-950 text-cyan-500 accent-cyan-500 cursor-pointer"
                        />
                      </div>

                      <div className="flex items-center gap-2 font-mono text-xs">
                        <span className="text-slate-400 font-bold">{item.id}</span>
                        <span className="text-slate-600">•</span>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                            item.status === 'pending'
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                              : item.status === 'approved'
                              ? 'bg-red-500/20 text-red-300 border border-red-500/30'
                              : item.status === 'released'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {item.status}
                        </span>
                      </div>
                    </div>

                    <span className="text-xs font-mono font-bold text-red-400 shrink-0">
                      Risk: {item.riskScore}/100
                    </span>
                  </div>

                  <div className="pl-7">
                    <h3 className="text-sm font-semibold text-white truncate">{item.target}</h3>
                    {item.sender && (
                      <div className="text-xs text-slate-400 font-mono mt-1 truncate">
                        Sender: {item.sender}
                      </div>
                    )}

                    <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500 font-mono">
                      <span>Logged: {new Date(item.createdAt).toLocaleTimeString()}</span>
                      {item.reviewedBy && <span>Reviewed by: {item.reviewedBy}</span>}
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="p-8 rounded-xl bg-slate-900/30 border border-slate-800 text-center text-xs text-slate-500 font-mono">
              No quarantine requests in this view.
            </div>
          )}
        </div>

        {/* Selected Incident Review & Action Panel */}
        <div className="lg:col-span-5 space-y-4">
          {selectedItem ? (
            <div className="p-5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-4 animate-in fade-in duration-200">
              <div className="border-b border-slate-800 pb-3">
                <div className="text-[10px] font-mono text-cyan-400 uppercase font-semibold">
                  INCIDENT TRIAGE CONSOLE
                </div>
                <h3 className="text-sm font-bold text-white mt-1">{selectedItem.target}</h3>
                <div className="text-xs font-mono text-slate-400 mt-1">
                  Incident: {selectedItem.id} | Scan ID: {selectedItem.scanId}
                </div>
              </div>

              {/* Status details */}
              <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">CURRENT STATUS</span>
                  <span className="text-cyan-400 font-bold uppercase">{selectedItem.status}</span>
                </div>
                <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">RISK ASSESSMENT</span>
                  <span className="text-red-400 font-bold">{selectedItem.riskScore}/100</span>
                </div>
              </div>

              {/* Analyst Notes */}
              <div>
                <label className="block text-xs font-mono text-slate-300 font-semibold mb-1">
                  SOC ANALYST INVESTIGATION NOTES
                </label>
                <textarea
                  rows={4}
                  value={analystNotes}
                  onChange={(e) => setAnalystNotes(e.target.value)}
                  placeholder="Record justification, recipient notification status, or sandbox findings..."
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg p-2.5 text-xs text-slate-200 placeholder-slate-600 font-mono outline-none resize-y"
                />
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <div className="text-[10px] font-mono text-slate-500 uppercase">
                  AUTHORIZED RESPONSE ACTIONS
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleSingleAction('approved')}
                    disabled={actionLoading || selectedItem.status === 'approved'}
                    className="py-2 px-3 rounded-lg bg-red-600 hover:bg-red-500 disabled:opacity-40 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Approve Quarantine
                  </button>

                  <button
                    onClick={() => handleSingleAction('rejected')}
                    disabled={actionLoading || selectedItem.status === 'rejected'}
                    className="py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <XCircle className="w-4 h-4" />
                    Reject Hold
                  </button>
                </div>

                <button
                  onClick={() => handleSingleAction('released')}
                  disabled={actionLoading || selectedItem.status === 'released'}
                  className="w-full py-2 px-3 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <RotateCcw className="w-4 h-4" />
                  Mark as False Positive & Release to Inbox
                </button>
              </div>
            </div>
          ) : (
            <div className="p-8 rounded-xl bg-slate-900/30 border border-slate-800 text-center flex flex-col items-center justify-center min-h-[300px]">
              <FileText className="w-8 h-8 text-slate-500 mb-2" />
              <h3 className="text-xs font-semibold text-slate-300 font-mono">Select a Quarantine Item</h3>
              <p className="text-[11px] text-slate-500 max-w-xs mt-1">
                Click any incident on the left to review analyst notes, or use checkboxes for bulk one-click approval.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
