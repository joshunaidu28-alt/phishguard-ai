import React, { useState } from 'react';
import {
  History,
  Search,
  Filter,
  Download,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  ExternalLink,
  ChevronRight,
  RefreshCw,
  FileSpreadsheet,
  CheckCircle2,
} from 'lucide-react';
import { ScanRecord } from '../types';
import { PageId } from '../components/Sidebar';

interface DetectionHistoryProps {
  scans: ScanRecord[];
  onNavigate: (page: PageId, targetScanId?: string) => void;
}

export const DetectionHistory: React.FC<DetectionHistoryProps> = ({ scans, onNavigate }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [verdictFilter, setVerdictFilter] = useState<string>('all');
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  const filteredScans = scans.filter((s) => {
    const matchesSearch =
      (s.target || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (s.sender || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (s.id || '').toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = typeFilter === 'all' || s.scanType === typeFilter;
    const matchesVerdict = verdictFilter === 'all' || s.classification === verdictFilter;
    return matchesSearch && matchesType && matchesVerdict;
  });

  const handleDownloadCSV = () => {
    const headers = [
      'Scan ID',
      'Scan Type',
      'Target / Subject',
      'Sender',
      'Recipient',
      'Classification Verdict',
      'Risk Score',
      'Confidence',
      'Status',
      'Timestamp (UTC)',
      'Evidence Summary',
      'Recommended Action',
      'Extracted URLs Count',
    ];

    const rows = filteredScans.map((s) => [
      s.id,
      s.scanType,
      `"${(s.target || s.subject || '').replace(/"/g, '""')}"`,
      `"${(s.sender || '').replace(/"/g, '""')}"`,
      `"${(s.recipient || '').replace(/"/g, '""')}"`,
      s.classification,
      s.riskScore,
      `${s.confidence}%`,
      s.status,
      s.createdAt,
      `"${(s.evidenceSummary || '').replace(/"/g, '""')}"`,
      `"${(s.recommendedAction || '').replace(/"/g, '""')}"`,
      s.extractedUrls ? s.extractedUrls.length : 0,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute(
      'download',
      `phishguard-scan-logs-${new Date().toISOString().split('T')[0]}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  const handleExportJSON = () => {
    const dataStr =
      'data:text/json;charset=utf-8,' +
      encodeURIComponent(JSON.stringify(filteredScans, null, 2));
    const link = document.createElement('a');
    link.setAttribute('href', dataStr);
    link.setAttribute(
      'download',
      `phishguard-scans-${new Date().toISOString().split('T')[0]}.json`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-900">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight font-mono flex items-center gap-2">
            <History className="w-5 h-5 text-cyan-400" />
            Threat Detection History & Historical Audits
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Complete database log of all analyzed emails, URLs, domain indicators, and forensic scores.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {downloadSuccess && (
            <span className="text-xs text-emerald-400 font-mono flex items-center gap-1 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4" />
              CSV Exported ({filteredScans.length} records)
            </span>
          )}

          {/* Prominent Download CSV Button */}
          <button
            onClick={handleDownloadCSV}
            className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs font-mono shadow-md shadow-cyan-500/20 transition-all flex items-center gap-1.5 active:scale-95"
            title="Download CSV for external reporting and audit compliance"
          >
            <Download className="w-3.5 h-3.5" />
            Download CSV
          </button>

          <button
            onClick={handleExportJSON}
            className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-mono transition-colors flex items-center gap-1.5"
            title="Export JSON telemetry"
          >
            <Download className="w-3.5 h-3.5" />
            Export JSON
          </button>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by target, subject, sender, or ID..."
            className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-600 outline-none"
          />
        </div>

        {/* Dropdowns */}
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="flex items-center gap-1.5 text-xs text-slate-400 font-mono">
            <Filter className="w-3.5 h-3.5 text-cyan-400" />
            <span>Type:</span>
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-slate-300 text-xs outline-none"
            >
              <option value="all">All Types</option>
              <option value="email">Email</option>
              <option value="url">URL</option>
              <option value="header">Header</option>
              <option value="domain">Domain</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-400 font-mono">
            <span>Verdict:</span>
            <select
              value={verdictFilter}
              onChange={(e) => setVerdictFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-slate-300 text-xs outline-none"
            >
              <option value="all">All Verdicts</option>
              <option value="Phishing">Phishing</option>
              <option value="Suspicious">Suspicious</option>
              <option value="Safe">Safe</option>
            </select>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="border-b border-slate-800 text-slate-500 font-mono text-[11px]">
              <th className="pb-3 font-medium">SCAN ID</th>
              <th className="pb-3 font-medium">TYPE</th>
              <th className="pb-3 font-medium">TARGET / SUBJECT</th>
              <th className="pb-3 font-medium">VERDICT</th>
              <th className="pb-3 font-medium">RISK SCORE</th>
              <th className="pb-3 font-medium">CONFIDENCE</th>
              <th className="pb-3 font-medium">STATUS</th>
              <th className="pb-3 font-medium">TIMESTAMP</th>
              <th className="pb-3 font-medium text-right">EXAMINE</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {filteredScans.length > 0 ? (
              filteredScans.map((scan) => (
                <tr key={scan.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 font-mono text-[11px] text-slate-400 select-all">{scan.id}</td>
                  <td className="py-3 font-mono text-[11px]">
                    <span className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-300 uppercase">
                      {scan.scanType}
                    </span>
                  </td>
                  <td className="py-3 max-w-[260px] truncate font-medium text-slate-200">
                    <div>{scan.target || 'Untitled'}</div>
                    {scan.sender && <div className="text-[10px] text-slate-500 font-mono truncate">{scan.sender}</div>}
                  </td>
                  <td className="py-3">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono ${
                        scan.classification === 'Phishing'
                          ? 'bg-red-500/20 text-red-300 border border-red-500/30'
                          : scan.classification === 'Suspicious'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      }`}
                    >
                      {scan.classification}
                    </span>
                  </td>
                  <td className="py-3 font-mono font-bold">
                    <span
                      className={
                        scan.riskScore >= 70
                          ? 'text-red-400'
                          : scan.riskScore >= 35
                          ? 'text-amber-400'
                          : 'text-emerald-400'
                      }
                    >
                      {scan.riskScore}/100
                    </span>
                  </td>
                  <td className="py-3 font-mono text-slate-400">{scan.confidence}%</td>
                  <td className="py-3 font-mono text-[11px]">
                    <span
                      className={`capitalize ${
                        scan.status === 'quarantined'
                          ? 'text-cyan-400 font-semibold'
                          : scan.status === 'released'
                          ? 'text-emerald-400'
                          : 'text-slate-400'
                      }`}
                    >
                      {scan.status}
                    </span>
                  </td>
                  <td className="py-3 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                    {new Date(scan.createdAt).toLocaleString([], {
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </td>
                  <td className="py-3 text-right">
                    <button
                      onClick={() => onNavigate('threat_explanation', scan.id)}
                      className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-cyan-400 hover:text-cyan-300 text-xs font-mono transition-colors"
                    >
                      View AI
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={9} className="py-8 text-center text-xs text-slate-500 font-mono">
                  No scan records matched your filter criteria.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
