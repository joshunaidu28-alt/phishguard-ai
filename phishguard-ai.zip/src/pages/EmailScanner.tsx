import React, { useState } from 'react';
import {
  Mail,
  Upload,
  AlertOctagon,
  ShieldCheck,
  AlertTriangle,
  FileText,
  Link,
  Brain,
  ArchiveRestore,
  Sparkles,
  Loader2,
  ChevronRight,
  Info,
  CheckCircle2,
  Send,
} from 'lucide-react';
import { EmailScanResult, ScanRecord } from '../types';
import { saveScanRecord, createQuarantineRequest, logSecurityAudit } from '../services/dataService';
import { useAuth } from '../context/AuthContext';
import { PageId } from '../components/Sidebar';

interface EmailScannerProps {
  onScanSaved: (scan: ScanRecord) => void;
  onNavigate: (page: PageId, targetScanId?: string) => void;
}

export const EmailScanner: React.FC<EmailScannerProps> = ({ onScanSaved, onNavigate }) => {
  const { user } = useAuth();

  const [sender, setSender] = useState('');
  const [recipient, setRecipient] = useState('');
  const [subject, setSubject] = useState('');
  const [headers, setHeaders] = useState('');
  const [body, setBody] = useState('');
  const [emlFileName, setEmlFileName] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [scanResult, setScanResult] = useState<EmailScanResult | null>(null);
  const [quarantineSubmitted, setQuarantineSubmitted] = useState(false);

  // Pre-configured test presets
  const samplePresets = [
    {
      title: 'Microsoft 365 Credential Harvest',
      sender: 'IT Account Support <security@micros0ft-support-alert.xyz>',
      recipient: 'alice.finance@enterprise.com',
      subject: 'URGENT: Your Office 365 Password Expires in 2 Hours',
      body: `Dear Alice,

Your Microsoft 365 account password will expire today at 5:00 PM. Failure to update your password immediately will result in complete account suspension and loss of email access.

Click the secure link below to verify your password and maintain uninterrupted access:
https://micros0ft-support-alert.xyz/auth/login?user=alice.finance

Thank you,
Microsoft IT Security Desk`,
      headers: `From: IT Account Support <security@micros0ft-support-alert.xyz>
To: alice.finance@enterprise.com
Reply-To: support-drop@phishbox.ru
Return-Path: <bounce@untrusted-relay.net>
Subject: URGENT: Your Office 365 Password Expires in 2 Hours
Authentication-Results: spf=fail (sender IP 194.26.29.112 not authorized); dkim=fail; dmarc=fail`,
    },
    {
      title: 'CEO Wire Transfer (BEC)',
      sender: 'David Vance <david.vance.ceo@gmail.com>',
      recipient: 'controller@enterprise.com',
      subject: 'Strictly Confidential: Acquisition Escrow Wire Transfer',
      body: `Are you in the office right now?

We are finalizing the confidential acquisition of Project Olympus. I need you to process an urgent wire transfer of $142,500 to our external escrow account before 2:00 PM today.

Do not call my mobile as I am currently in closed-door executive meetings with the board. Reply to this email with the wire confirmation number once executed.

David Vance
Chief Executive Officer`,
      headers: `From: David Vance <david.vance.ceo@gmail.com>
To: controller@enterprise.com
Reply-To: david.vance.ceo@gmail.com
Subject: Strictly Confidential: Acquisition Escrow Wire Transfer
Authentication-Results: spf=pass; dkim=pass (from gmail.com); dmarc=none`,
    },
    {
      title: 'Legitimate Engineering Standup',
      sender: 'Alex Chen <alex.chen@enterprise.internal>',
      recipient: 'engineering-all@enterprise.internal',
      subject: 'Sprint 44 Architecture Sync & Retrospective Notes',
      body: `Hi Team,

Great progress on Sprint 44. The architecture notes and meeting recording are now available on the internal wiki:
https://wiki.enterprise.internal/display/SEC/Sprint+44+Retro

Please review the action items for database schema migrations before tomorrow's deploy window.

Best regards,
Alex Chen`,
      headers: `From: Alex Chen <alex.chen@enterprise.internal>
To: engineering-all@enterprise.internal
Subject: Sprint 44 Architecture Sync & Retrospective Notes
Authentication-Results: spf=pass; dkim=pass (domain enterprise.internal); dmarc=pass`,
    },
  ];

  const applyPreset = (preset: typeof samplePresets[0]) => {
    setSender(preset.sender);
    setRecipient(preset.recipient);
    setSubject(preset.subject);
    setBody(preset.body);
    setHeaders(preset.headers);
    setEmlFileName('');
    setScanResult(null);
    setQuarantineSubmitted(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.eml') && !file.name.endsWith('.txt') && !file.name.endsWith('.msg')) {
      setError('Please upload an RFC-compliant .eml or email text file.');
      return;
    }

    setEmlFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setBody(content);
      // Attempt quick header extraction
      const headerMatch = content.match(/^([\s\S]+?)\r?\n\r?\n/);
      if (headerMatch) {
        setHeaders(headerMatch[1]);
      }
    };
    reader.readAsText(file);
  };

  const handleScan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!body.trim() && !subject.trim() && !headers.trim()) {
      setError('Please provide email content, subject, or headers to analyze.');
      return;
    }

    setLoading(true);
    setError(null);
    setScanResult(null);
    setQuarantineSubmitted(false);

    try {
      const response = await fetch('/api/v1/emails/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sender,
          recipient,
          subject,
          body,
          headers,
          emlContent: emlFileName ? body : undefined,
        }),
      });

      if (!response.ok) {
        throw new Error('Scan failed: ' + response.statusText);
      }

      const result: EmailScanResult = await response.json();
      setScanResult(result);

      // Save to Firestore scan history
      const scanRecord: Omit<ScanRecord, 'id'> = {
        userId: user?.uid || 'guest-analyst',
        userEmail: user?.email || 'guest@phishguard.internal',
        scanType: 'email',
        target: subject || result.metadata.subject || 'Analyzed Email Payload',
        sender: sender || result.metadata.from,
        recipient: recipient || result.metadata.to,
        subject: subject || result.metadata.subject,
        classification: result.classification,
        riskScore: result.riskScore,
        confidence: result.confidence,
        evidenceSummary: result.indicators.map((i) => i.description).join('; '),
        recommendedAction: result.recommendedAction,
        aiExplanation: result.aiExplanation,
        status: result.riskScore >= 70 ? 'quarantined' : 'analyzed',
        createdAt: new Date().toISOString(),
        indicators: result.indicators,
        tactics: result.tactics,
        extractedUrls: result.extractedUrls,
        parsedHeaders: result.parsedHeaders,
      };

      const savedId = await saveScanRecord(scanRecord);
      onScanSaved({ ...scanRecord, id: savedId });

      // Automatically log audit event
      await logSecurityAudit(
        user?.uid || 'guest-analyst',
        user?.email || 'guest@phishguard.internal',
        'EMAIL_SCAN_COMPLETED',
        `Scanned email "${subject || 'Untitled'}" - Verdict: ${result.classification} (${result.riskScore}/100)`,
        savedId
      );
    } catch (err: any) {
      console.error('Scan error:', err);
      setError(err.message || 'Failed to analyze email.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuarantine = async () => {
    if (!scanResult || quarantineSubmitted) return;
    try {
      await createQuarantineRequest(
        user?.uid || 'analyst',
        scanResult.scanId,
        scanResult.metadata.subject || subject || 'Suspicious Email',
        scanResult.metadata.from || sender || 'Unknown Sender',
        scanResult.riskScore,
        `Flagged by analyst via Email Scanner: ${scanResult.aiExplanation.slice(0, 300)}`
      );
      setQuarantineSubmitted(true);
      await logSecurityAudit(
        user?.uid || 'analyst',
        user?.email || 'analyst@phishguard.internal',
        'QUARANTINE_REQUESTED',
        `Submitted quarantine request for scan ${scanResult.scanId}`,
        scanResult.scanId
      );
    } catch (err: any) {
      setError('Quarantine request failed: ' + err.message);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-900">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight font-mono flex items-center gap-2">
            <Mail className="w-5 h-5 text-cyan-400" />
            AI Email Threat Scanner & NLP Engine
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Deep multi-layered inspection: RFC headers, lookalike spoofing, social engineering triggers, and Gemini 3.8 Flash analysis.
          </p>
        </div>
      </div>

      {/* Preset sample templates */}
      <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs text-slate-300 font-mono">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          <span>Quick Load Test Payloads:</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {samplePresets.map((p, idx) => (
            <button
              key={idx}
              onClick={() => applyPreset(p)}
              className="text-xs px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-cyan-300 border border-slate-700 transition-colors"
            >
              {p.title}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Input Form Column */}
        <div className="lg:col-span-7 space-y-4">
          <form onSubmit={handleScan} className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-4">
            {/* File Upload Banner */}
            <div className="border border-dashed border-slate-700 hover:border-cyan-500/50 rounded-lg p-4 text-center transition-colors bg-slate-950/40">
              <Upload className="w-6 h-6 text-slate-400 mx-auto mb-1.5" />
              <label className="cursor-pointer text-xs font-semibold text-cyan-400 hover:text-cyan-300">
                <span>Upload RFC-822 .eml or .txt message file</span>
                <input
                  type="file"
                  accept=".eml,.txt,.msg"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
              {emlFileName && (
                <div className="mt-2 text-[11px] font-mono text-emerald-400 flex items-center justify-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Loaded file: {emlFileName}
                </div>
              )}
            </div>

            {/* Envelope Fields */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">FROM (SENDER)</label>
                <input
                  type="text"
                  value={sender}
                  onChange={(e) => setSender(e.target.value)}
                  placeholder="e.g. IT Desk <support@brand-verify.com>"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg px-3 py-2 text-xs text-slate-200 placeholder-slate-600 outline-none"
                />
              </div>
              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">TO (RECIPIENT)</label>
                <input
                  type="text"
                  value={recipient}
                  onChange={(e) => setRecipient(e.target.value)}
                  placeholder="e.g. employee@company.com"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg px-3 py-2 text-xs text-slate-200 placeholder-slate-600 outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-mono text-slate-400 mb-1">SUBJECT</label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="e.g. Urgent: Account Security Notice"
                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg px-3 py-2 text-xs text-slate-200 placeholder-slate-600 outline-none"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[11px] font-mono text-slate-400">EMAIL BODY CONTENT</label>
                <span className="text-[10px] text-slate-500">Plain text or HTML</span>
              </div>
              <textarea
                rows={6}
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder="Paste the raw email text or message content here..."
                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg p-3 text-xs text-slate-200 placeholder-slate-600 font-mono outline-none resize-y"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[11px] font-mono text-slate-400">
                  RAW RFC HEADERS <span className="text-slate-500">(Optional for deeper hop trace)</span>
                </label>
              </div>
              <textarea
                rows={3}
                value={headers}
                onChange={(e) => setHeaders(e.target.value)}
                placeholder="Received: from mail.untrusted.com ...&#10;Authentication-Results: spf=fail; dkim=fail"
                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg p-3 text-xs text-slate-200 placeholder-slate-600 font-mono outline-none resize-y"
              />
            </div>

            {error && (
              <div className="p-3 rounded-lg bg-red-950/40 border border-red-900/50 text-red-300 text-xs flex items-center gap-2">
                <AlertOctagon className="w-4 h-4 text-red-400 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-50 text-slate-950 font-bold text-xs tracking-wide shadow-lg shadow-cyan-500/20 transition-all flex items-center justify-center gap-2 active:scale-98"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Running Neural Classification & Header Anomaly Check...
                </>
              ) : (
                <>
                  <Brain className="w-4 h-4" />
                  Analyze Threat with PhishGuard AI
                </>
              )}
            </button>
          </form>
        </div>

        {/* Scan Results Column */}
        <div className="lg:col-span-5 space-y-4">
          {scanResult ? (
            <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-5 animate-in fade-in duration-300">
              {/* Verdict Banner */}
              <div
                className={`p-4 rounded-xl border flex items-center justify-between ${
                  scanResult.classification === 'Phishing'
                    ? 'bg-red-950/40 border-red-500/40 text-red-300'
                    : scanResult.classification === 'Suspicious'
                    ? 'bg-amber-950/40 border-amber-500/40 text-amber-300'
                    : 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                }`}
              >
                <div>
                  <div className="text-[10px] font-mono tracking-wider uppercase opacity-80">
                    CLASSIFICATION VERDICT
                  </div>
                  <div className="text-xl font-bold font-mono tracking-tight flex items-center gap-2 mt-0.5">
                    {scanResult.classification === 'Phishing' && <AlertOctagon className="w-5 h-5 text-red-400" />}
                    {scanResult.classification === 'Suspicious' && <AlertTriangle className="w-5 h-5 text-amber-400" />}
                    {scanResult.classification === 'Safe' && <ShieldCheck className="w-5 h-5 text-emerald-400" />}
                    {scanResult.classification}
                  </div>
                </div>
                <div className="text-right font-mono">
                  <div className="text-2xl font-black">{scanResult.riskScore}/100</div>
                  <div className="text-[10px] opacity-80">Confidence: {scanResult.confidence}%</div>
                </div>
              </div>

              {/* Recommended Action */}
              <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800">
                <div className="text-[10px] font-mono text-cyan-400 uppercase font-semibold mb-1 flex items-center gap-1">
                  <Info className="w-3.5 h-3.5" />
                  RECOMMENDED SOC ACTION
                </div>
                <p className="text-xs text-slate-200 font-medium">{scanResult.recommendedAction}</p>
              </div>

              {/* Explainable AI Analysis */}
              <div>
                <h4 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  Gemini Threat Analysis & Evidence
                </h4>
                <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3 rounded-lg border border-slate-800">
                  {scanResult.aiExplanation}
                </p>
              </div>

              {/* Detected Indicators */}
              {scanResult.indicators.length > 0 && (
                <div>
                  <h4 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider mb-2">
                    Key Technical Indicators ({scanResult.indicators.length})
                  </h4>
                  <div className="space-y-2">
                    {scanResult.indicators.map((ind, idx) => (
                      <div
                        key={idx}
                        className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800 text-xs flex items-start gap-2"
                      >
                        <span
                          className={`mt-0.5 px-1.5 py-0.2 rounded text-[9px] font-mono font-bold uppercase ${
                            ind.severity === 'critical'
                              ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                              : ind.severity === 'high'
                              ? 'bg-orange-500/20 text-orange-400 border border-orange-500/30'
                              : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          }`}
                        >
                          {ind.severity}
                        </span>
                        <div>
                          <div className="font-semibold text-slate-200 text-[11px]">{ind.category}</div>
                          <div className="text-slate-400 text-[11px] mt-0.5">{ind.description}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Extracted URLs */}
              {scanResult.extractedUrls.length > 0 && (
                <div>
                  <h4 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Link className="w-3.5 h-3.5 text-cyan-400" />
                    Extracted Embedded URLs ({scanResult.extractedUrls.length})
                  </h4>
                  <div className="space-y-1.5">
                    {scanResult.extractedUrls.map((url, idx) => (
                      <div
                        key={idx}
                        className="p-2 rounded bg-slate-950 border border-slate-800 text-[11px] font-mono text-cyan-300 break-all select-all flex items-center justify-between"
                      >
                        <span className="truncate mr-2">{url}</span>
                        <button
                          onClick={() => onNavigate('url_scanner')}
                          className="shrink-0 text-[10px] text-slate-400 hover:text-cyan-400 underline"
                        >
                          Scan URL
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Action Buttons: Quarantine, Explain in Full Page */}
              <div className="pt-3 border-t border-slate-800 flex items-center gap-2">
                {scanResult.riskScore >= 40 && (
                  <button
                    onClick={handleQuarantine}
                    disabled={quarantineSubmitted}
                    className="flex-1 py-2 rounded-lg bg-red-600 hover:bg-red-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-semibold text-xs transition-colors flex items-center justify-center gap-1.5"
                  >
                    <ArchiveRestore className="w-4 h-4" />
                    {quarantineSubmitted ? 'Quarantine Requested ✓' : 'Submit for Quarantine'}
                  </button>
                )}
                <button
                  onClick={() => onNavigate('threat_explanation', scanResult.scanId)}
                  className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors flex items-center gap-1"
                >
                  Full AI Explanation <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ) : (
            <div className="p-8 rounded-xl bg-slate-900/30 border border-slate-800/80 text-center flex flex-col items-center justify-center min-h-[350px]">
              <div className="p-3 rounded-full bg-slate-800/60 text-slate-500 mb-3">
                <FileText className="w-8 h-8" />
              </div>
              <h3 className="text-sm font-semibold text-slate-300 font-mono">No Email Analyzed Yet</h3>
              <p className="text-xs text-slate-500 max-w-xs mt-1">
                Enter an email or select one of the test presets above to trigger the neural phishing engine.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
