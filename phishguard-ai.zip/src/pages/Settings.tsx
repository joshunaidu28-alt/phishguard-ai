import React, { useState } from 'react';
import {
  Sliders,
  Shield,
  Save,
  CheckCircle2,
  AlertTriangle,
  Info,
  Server,
  Bell,
  Cpu,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { logSecurityAudit } from '../services/dataService';

export const Settings: React.FC = () => {
  const { user, isAdmin } = useAuth();

  const [sensitivity, setSensitivity] = useState<'Standard' | 'Balanced' | 'Aggressive' | 'Zero-Tolerance'>('Aggressive');
  const [quarantineThreshold, setQuarantineThreshold] = useState(70);
  const [suspiciousThreshold, setSuspiciousThreshold] = useState(35);
  const [enableDkimStrict, setEnableDkimStrict] = useState(true);
  const [enableHomoglyphCheck, setEnableHomoglyphCheck] = useState(true);
  const [enableAutoQuarantineRecommendation, setEnableAutoQuarantineRecommendation] = useState(true);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) {
      alert('Only administrators can update global detection policies.');
      return;
    }

    setSavedSuccess(true);
    await logSecurityAudit(
      user?.uid || 'admin',
      user?.email || 'admin@phishguard.internal',
      'DETECTION_POLICY_UPDATED',
      `Updated sensitivity to ${sensitivity}, quarantine threshold to ${quarantineThreshold}`
    );
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-900">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight font-mono flex items-center gap-2">
            <Sliders className="w-5 h-5 text-cyan-400" />
            Detection Policy & Platform Settings
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Configure risk score weighting coefficients, quarantine trigger points, and neural model sensitivities.
          </p>
        </div>

        {savedSuccess && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-950/40 border border-emerald-900/50 text-emerald-400 text-xs font-mono animate-in fade-in">
            <CheckCircle2 className="w-4 h-4" />
            Settings Saved to SOC Policy!
          </div>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Detection Engine Tuning */}
        <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-5">
          <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <Cpu className="w-4 h-4 text-cyan-400" />
            Neural Engine & Risk Threshold Calibration
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs font-mono text-slate-300 font-semibold mb-1">
                DETECTION SENSITIVITY PROFILE
              </label>
              <select
                value={sensitivity}
                onChange={(e: any) => setSensitivity(e.target.value)}
                disabled={!isAdmin}
                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg px-3 py-2 text-xs text-slate-200 font-mono outline-none"
              >
                <option value="Standard">Standard (Low False Positive Tolerance)</option>
                <option value="Balanced">Balanced (Default Enterprise Posture)</option>
                <option value="Aggressive">Aggressive (High-Risk Urgency Penalty)</option>
                <option value="Zero-Tolerance">Zero-Tolerance (Maximum Isolation for Any Anomaly)</option>
              </select>
              <p className="text-[11px] text-slate-500 mt-1">
                Controls the baseline decision boundary weights between Safe, Suspicious, and Phishing.
              </p>
            </div>

            <div>
              <label className="block text-xs font-mono text-slate-300 font-semibold mb-1">
                AUTO-QUARANTINE THRESHOLD SCORE: <span className="text-cyan-400 font-mono font-bold">{quarantineThreshold}/100</span>
              </label>
              <input
                type="range"
                min="50"
                max="95"
                step="5"
                value={quarantineThreshold}
                onChange={(e) => setQuarantineThreshold(parseInt(e.target.value, 10))}
                disabled={!isAdmin}
                className="w-full accent-cyan-400 bg-slate-950"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
                <span>50 (Sensitive)</span>
                <span>70 (Recommended)</span>
                <span>95 (Strict Critical Only)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Security Rule Toggles */}
        <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-4">
          <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <Shield className="w-4 h-4 text-cyan-400" />
            Heuristic Gates & Authentication Policies
          </h3>

          <div className="space-y-3">
            <label className="flex items-center justify-between p-3 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
              <div>
                <div className="text-xs font-semibold text-slate-200 font-mono">Strict DKIM & DMARC Alignment Verification</div>
                <div className="text-[11px] text-slate-500">Automatically flag messages with mismatched sender envelope domains as Suspicious.</div>
              </div>
              <input
                type="checkbox"
                checked={enableDkimStrict}
                onChange={(e) => setEnableDkimStrict(e.target.checked)}
                disabled={!isAdmin}
                className="w-4 h-4 accent-cyan-400"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
              <div>
                <div className="text-xs font-semibold text-slate-200 font-mono">IDN Homoglyph & Typosquatting Interceptor</div>
                <div className="text-[11px] text-slate-500">Inspect Unicode punycode (xn--) and visual character substitutions (0 for o, 1 for l).</div>
              </div>
              <input
                type="checkbox"
                checked={enableHomoglyphCheck}
                onChange={(e) => setEnableHomoglyphCheck(e.target.checked)}
                disabled={!isAdmin}
                className="w-4 h-4 accent-cyan-400"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
              <div>
                <div className="text-xs font-semibold text-slate-200 font-mono">Proactive Quarantine Recommendations</div>
                <div className="text-[11px] text-slate-500">Automatically route scores &ge; {quarantineThreshold} to the Analyst Quarantine Queue.</div>
              </div>
              <input
                type="checkbox"
                checked={enableAutoQuarantineRecommendation}
                onChange={(e) => setEnableAutoQuarantineRecommendation(e.target.checked)}
                disabled={!isAdmin}
                className="w-4 h-4 accent-cyan-400"
              />
            </label>
          </div>
        </div>

        {/* System Telemetry & Environment */}
        <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-3 text-xs font-mono">
          <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <Server className="w-4 h-4 text-cyan-400" />
            Environment & Core Telemetry
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3 rounded bg-slate-950 border border-slate-850">
              <span className="text-slate-500 block text-[10px]">PLATFORM VERSION</span>
              <span className="text-slate-200 font-bold">PhishGuard v2.5.0-prod</span>
            </div>
            <div className="p-3 rounded bg-slate-950 border border-slate-850">
              <span className="text-slate-500 block text-[10px]">AI MODEL ALIAS</span>
              <span className="text-cyan-400 font-bold">gemini-3.8-flash</span>
            </div>
            <div className="p-3 rounded bg-slate-950 border border-slate-850">
              <span className="text-slate-500 block text-[10px]">DATABASE ENGINE</span>
              <span className="text-amber-400 font-bold">Cloud Firestore</span>
            </div>
          </div>
        </div>

        {/* Submit */}
        {isAdmin && (
          <button
            type="submit"
            className="px-6 py-2.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs tracking-wide shadow-lg shadow-cyan-500/20 transition-all flex items-center gap-2 active:scale-98"
          >
            <Save className="w-4 h-4" />
            Save Detection Policy Changes
          </button>
        )}
      </form>
    </div>
  );
};
