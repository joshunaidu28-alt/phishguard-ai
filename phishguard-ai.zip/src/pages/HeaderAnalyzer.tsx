import React, { useState } from 'react';
import {
  FileCode2,
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  ArrowRight,
  Route,
  Loader2,
  Sparkles,
  Info,
  Server,
} from 'lucide-react';
import { HeaderAnalysisResult } from '../types';
import { useAuth } from '../context/AuthContext';
import { logSecurityAudit } from '../services/dataService';

export const HeaderAnalyzer: React.FC = () => {
  const { user } = useAuth();
  const [headersInput, setHeadersInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<HeaderAnalysisResult | null>(null);

  const sampleHeader = `Delivered-To: victim.executive@target-firm.com
Received: by 2002:a05:6e02:18c4:0:0:0:0 with SMTP id e4csp1283921
        Thu, 5 Nov 2026 14:22:10 -0800 (PST)
Received: from mail-relay-eu.untrusted-host.xyz (mail-relay-eu.untrusted-host.xyz. [194.26.29.112])
        by mx.google.com with ESMTPS id j9si3920194pll.142
        for <victim.executive@target-firm.com>;
        Thu, 05 Nov 2026 14:22:09 -0800 (PST)
Received-SPF: fail (google.com: domain of bounce@untrusted-host.xyz does not designate 194.26.29.112 as permitted sender) client-ip=194.26.29.112;
Authentication-Results: mx.google.com;
       dkim=fail header.i=@target-firm.com header.s=selector1;
       spf=fail (google.com: domain of bounce@untrusted-host.xyz does not designate 194.26.29.112 as permitted sender) smtp.mailfrom=bounce@untrusted-host.xyz;
       dmarc=fail (p=REJECT sp=REJECT dis=NONE) header.from=target-firm.com
From: CEO Office <ceo@target-firm.com>
To: victim.executive@target-firm.com
Reply-To: wire-escrow-desk@phishnet.ru
Return-Path: <bounce@untrusted-host.xyz>
Subject: Action Required: Wire Transfer Approval
Date: Thu, 05 Nov 2026 22:21:45 +0000
Message-ID: <8910421.20261105@target-firm.com>`;

  const handleAnalyze = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!headersInput.trim()) {
      setError('Please paste raw email headers to analyze.');
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('/api/v1/headers/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ headers: headersInput }),
      });

      if (!response.ok) {
        throw new Error('Analysis failed: ' + response.statusText);
      }

      const data: HeaderAnalysisResult = await response.json();
      setResult(data);

      await logSecurityAudit(
        user?.uid || 'analyst',
        user?.email || 'analyst@phishguard.internal',
        'HEADER_ANALYSIS',
        `Analyzed RFC headers from ${data.summary.from || 'unknown'} - Verdict: ${data.verdict}`
      );
    } catch (err: any) {
      setError(err.message || 'Failed to parse email headers.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-900">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight font-mono flex items-center gap-2">
            <FileCode2 className="w-5 h-5 text-cyan-400" />
            Email Header Analyzer & Relay Trace
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Deep forensic audit of SPF, DKIM, DMARC, Received routing hops, and sender envelope mismatches.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Input */}
        <div className="lg:col-span-6 space-y-4">
          <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-xs font-mono text-slate-300 font-semibold">
                PASTE RAW RFC HEADERS
              </label>
              <button
                type="button"
                onClick={() => setHeadersInput(sampleHeader)}
                className="text-[11px] font-mono text-cyan-400 hover:underline flex items-center gap-1"
              >
                <Sparkles className="w-3.5 h-3.5" />
                Load Spoofed Header Sample
              </button>
            </div>

            <textarea
              rows={14}
              value={headersInput}
              onChange={(e) => setHeadersInput(e.target.value)}
              placeholder="Paste RFC 5322 email headers here (Received, Authentication-Results, From, Reply-To, etc.)..."
              className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg p-3 text-xs text-slate-200 placeholder-slate-600 font-mono outline-none resize-y"
            />

            {error && (
              <div className="p-3 rounded-lg bg-red-950/40 border border-red-900/50 text-red-300 text-xs">
                {error}
              </div>
            )}

            <button
              onClick={handleAnalyze}
              disabled={loading || !headersInput.trim()}
              className="w-full py-2.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-50 text-slate-950 font-bold text-xs tracking-wide shadow-lg shadow-cyan-500/20 transition-all flex items-center justify-center gap-2 active:scale-98"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Tracing MTA Relay Hops & Cryptographic Signatures...
                </>
              ) : (
                <>
                  <Route className="w-4 h-4" />
                  Analyze Email Headers
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Results */}
        <div className="lg:col-span-6 space-y-4">
          {result ? (
            <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-5 animate-in fade-in duration-300">
              {/* Verdict Banner */}
              <div
                className={`p-4 rounded-xl border flex items-center justify-between ${
                  result.riskScore >= 70
                    ? 'bg-red-950/40 border-red-500/40 text-red-300'
                    : result.riskScore >= 35
                    ? 'bg-amber-950/40 border-amber-500/40 text-amber-300'
                    : 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                }`}
              >
                <div>
                  <div className="text-[10px] font-mono tracking-wider uppercase opacity-80">
                    HEADER AUTHENTICATION VERDICT
                  </div>
                  <div className="text-lg font-bold font-mono tracking-tight mt-0.5">
                    {result.verdict}
                  </div>
                </div>
                <div className="text-right font-mono">
                  <div className="text-2xl font-black">{result.riskScore}/100</div>
                  <div className="text-[10px] opacity-80">{result.hopsCount} Relay Hops</div>
                </div>
              </div>

              {/* Authentication Status Grid */}
              <div className="grid grid-cols-3 gap-3">
                {/* SPF */}
                <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-center">
                  <div className="text-[10px] font-mono text-slate-500">SPF</div>
                  <div
                    className={`text-sm font-bold font-mono mt-0.5 ${
                      result.authentication.spf.status === 'PASS'
                        ? 'text-emerald-400'
                        : result.authentication.spf.status === 'FAIL'
                        ? 'text-red-400'
                        : 'text-slate-400'
                    }`}
                  >
                    {result.authentication.spf.status}
                  </div>
                </div>
                {/* DKIM */}
                <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-center">
                  <div className="text-[10px] font-mono text-slate-500">DKIM</div>
                  <div
                    className={`text-sm font-bold font-mono mt-0.5 ${
                      result.authentication.dkim.status === 'PASS'
                        ? 'text-emerald-400'
                        : result.authentication.dkim.status === 'FAIL'
                        ? 'text-red-400'
                        : 'text-slate-400'
                    }`}
                  >
                    {result.authentication.dkim.status}
                  </div>
                </div>
                {/* DMARC */}
                <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-center">
                  <div className="text-[10px] font-mono text-slate-500">DMARC</div>
                  <div
                    className={`text-sm font-bold font-mono mt-0.5 ${
                      result.authentication.dmarc.status === 'PASS'
                        ? 'text-emerald-400'
                        : result.authentication.dmarc.status === 'FAIL'
                        ? 'text-red-400'
                        : 'text-slate-400'
                    }`}
                  >
                    {result.authentication.dmarc.status}
                  </div>
                </div>
              </div>

              {/* Envelope Identity Details */}
              <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 space-y-2 text-xs font-mono">
                <div className="text-[10px] text-cyan-400 uppercase font-semibold">
                  ENVELOPE IDENTITY TRACE
                </div>
                <div className="flex items-center justify-between text-slate-300">
                  <span className="text-slate-500">From:</span>
                  <span className="text-slate-200 select-all truncate max-w-[280px]">
                    {result.summary.from || 'Not specified'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-slate-300">
                  <span className="text-slate-500">Return-Path:</span>
                  <span className="text-slate-200 select-all truncate max-w-[280px]">
                    {result.summary.returnPath || 'Not specified'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-slate-300">
                  <span className="text-slate-500">Reply-To:</span>
                  <span className="text-slate-200 select-all truncate max-w-[280px]">
                    {result.summary.replyTo || 'Not specified'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-slate-300">
                  <span className="text-slate-500">Message-ID:</span>
                  <span className="text-slate-200 select-all truncate max-w-[280px]">
                    {result.summary.messageId || 'Missing'}
                  </span>
                </div>
              </div>

              {/* Detected Anomalies */}
              <div>
                <h4 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider mb-2">
                  Header Security Findings ({result.anomalies.length})
                </h4>
                {result.anomalies.length > 0 ? (
                  <div className="space-y-1.5">
                    {result.anomalies.map((anom, idx) => (
                      <div
                        key={idx}
                        className="p-2.5 rounded-lg bg-slate-950 text-xs text-slate-300 font-mono border border-slate-800 flex items-start gap-2"
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-red-400 mt-1.5 shrink-0"></span>
                        <span>{anom}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-3 rounded-lg bg-emerald-950/30 border border-emerald-900/40 text-emerald-300 text-xs flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    No spoofing or authentication anomalies identified in headers.
                  </div>
                )}
              </div>

              {/* Received Hops */}
              <div>
                <h4 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Server className="w-3.5 h-3.5 text-cyan-400" />
                  Received MTA Relay Chain
                </h4>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {result.hops.map((hop) => (
                    <div
                      key={hop.hopNumber}
                      className="p-2.5 rounded bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-300"
                    >
                      <div className="flex items-center justify-between text-cyan-400 font-bold mb-1">
                        <span>Hop #{hop.hopNumber}</span>
                        <span className="text-slate-500 font-normal">MTA Relay</span>
                      </div>
                      <div className="truncate text-slate-400">{hop.raw}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="p-8 rounded-xl bg-slate-900/30 border border-slate-800/80 text-center flex flex-col items-center justify-center min-h-[350px]">
              <FileCode2 className="w-8 h-8 text-slate-500 mb-3" />
              <h3 className="text-sm font-semibold text-slate-300 font-mono">
                No Header Analyzed
              </h3>
              <p className="text-xs text-slate-500 max-w-xs mt-1">
                Paste RFC 5322 headers or load the sample spoofed header above to inspect the relay trace.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
