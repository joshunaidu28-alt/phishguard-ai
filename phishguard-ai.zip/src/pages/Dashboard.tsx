import React from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  MailCheck,
  Link2,
  ArchiveRestore,
  TrendingUp,
  Activity,
  ArrowUpRight,
  Clock,
  ExternalLink,
} from 'lucide-react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
} from 'recharts';
import { ScanRecord, QuarantineRecord } from '../types';
import { PageId } from '../components/Sidebar';

interface DashboardProps {
  scans: ScanRecord[];
  quarantine: QuarantineRecord[];
  onNavigate: (page: PageId, targetScanId?: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  scans,
  quarantine,
  onNavigate,
}) => {
  // Live dynamic calculations derived from actual records
  const totalEmailsScanned = scans.filter((s) => s.scanType === 'email').length;
  const totalUrlsScanned = scans.filter((s) => s.scanType === 'url').length;
  const phishingCount = scans.filter((s) => s.classification === 'Phishing').length;
  const suspiciousCount = scans.filter((s) => s.classification === 'Suspicious').length;
  const safeCount = scans.filter((s) => s.classification === 'Safe').length;
  const criticalThreats = scans.filter((s) => s.riskScore >= 80).length;
  const pendingQuarantines = quarantine.filter((q) => q.status === 'pending').length;

  const totalScans = scans.length;
  const detectionRate = totalScans > 0 ? Math.round(((phishingCount + suspiciousCount) / totalScans) * 100) : 0;

  // Threat Distribution Data
  const threatDistributionData = [
    { name: 'Phishing', value: phishingCount, color: '#ef4444' },
    { name: 'Suspicious', value: suspiciousCount, color: '#f59e0b' },
    { name: 'Safe / Clean', value: safeCount, color: '#10b981' },
  ];

  // Daily Scan Activity aggregation
  const activityMap: Record<string, { date: string; phishing: number; safe: number; suspicious: number }> = {};
  scans.forEach((s) => {
    const d = new Date(s.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric' });
    if (!activityMap[d]) {
      activityMap[d] = { date: d, phishing: 0, safe: 0, suspicious: 0 };
    }
    if (s.classification === 'Phishing') activityMap[d].phishing += 1;
    else if (s.classification === 'Suspicious') activityMap[d].suspicious += 1;
    else activityMap[d].safe += 1;
  });
  const dailyActivityData = Object.values(activityMap).slice(-7);

  // Most common indicators tally
  const indicatorCounts: Record<string, number> = {};
  scans.forEach((s) => {
    s.indicators?.forEach((ind) => {
      indicatorCounts[ind.category] = (indicatorCounts[ind.category] || 0) + 1;
    });
    s.tactics?.forEach((t) => {
      indicatorCounts[t] = (indicatorCounts[t] || 0) + 1;
    });
  });
  const topIndicators = Object.entries(indicatorCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-900">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight font-mono flex items-center gap-2">
            <Activity className="w-5 h-5 text-cyan-400" />
            Security Operations Center (SOC) Overview
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time phishing threat posture, machine learning telemetry, and enterprise incident triage.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('email_scanner')}
            className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/20 transition-all flex items-center gap-1.5 active:scale-95"
          >
            <MailCheck className="w-4 h-4" />
            Scan Email Now
          </button>
          <button
            onClick={() => onNavigate('url_scanner')}
            className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-medium transition-all flex items-center gap-1.5"
          >
            <Link2 className="w-4 h-4 text-cyan-400" />
            Scan URL
          </button>
        </div>
      </div>

      {/* Top 4 Primary Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Emails Scanned */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-cyan-500/40 transition-all group">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono text-slate-400">TOTAL EMAILS SCANNED</span>
            <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20">
              <MailCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono text-white">{totalEmailsScanned}</div>
          <div className="mt-2 flex items-center gap-1.5 text-[11px] text-slate-400">
            <span className="text-cyan-400 font-semibold">{totalUrlsScanned} URLs</span>
            <span>evaluated simultaneously</span>
          </div>
        </div>

        {/* Phishing Detected */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-red-500/40 transition-all group">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono text-slate-400">PHISHING DETECTED</span>
            <div className="p-2 rounded-lg bg-red-500/10 text-red-400 border border-red-500/20">
              <ShieldAlert className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono text-red-400">{phishingCount}</div>
          <div className="mt-2 flex items-center gap-1.5 text-[11px] text-slate-400">
            <span className="text-red-400 font-semibold">{criticalThreats} Critical Risk</span>
            <span>threat payloads</span>
          </div>
        </div>

        {/* Suspicious Alerts */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-amber-500/40 transition-all group">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono text-slate-400">SUSPICIOUS ANOMALIES</span>
            <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono text-amber-400">{suspiciousCount}</div>
          <div className="mt-2 flex items-center gap-1.5 text-[11px] text-slate-400">
            <span className="text-emerald-400 font-semibold">{safeCount} Safe messages</span>
            <span>cleared</span>
          </div>
        </div>

        {/* Quarantine Recommendations */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-cyan-500/40 transition-all group">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono text-slate-400">PENDING QUARANTINE</span>
            <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <ArchiveRestore className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono text-cyan-400">{pendingQuarantines}</div>
          <div className="mt-2 flex items-center justify-between text-[11px]">
            <span className="text-slate-400">Detection Rate: {detectionRate}%</span>
            <button
              onClick={() => onNavigate('quarantine')}
              className="text-cyan-400 hover:underline flex items-center"
            >
              Review <ArrowUpRight className="w-3 h-3 ml-0.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Visual Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Threat Distribution Pie Chart */}
        <div className="p-5 rounded-xl bg-slate-900/50 border border-slate-800 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider">
              Threat Distribution
            </h3>
            <span className="text-[11px] font-mono text-slate-500">Live Scans ({totalScans})</span>
          </div>
          <div className="h-52 w-full flex items-center justify-center">
            {totalScans > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={threatDistributionData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={75}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {threatDistributionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} stroke="#070b14" strokeWidth={2} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#070b14',
                      borderColor: '#1e293b',
                      borderRadius: '8px',
                      fontSize: '12px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-xs text-slate-500 font-mono">No scan telemetry recorded yet.</div>
            )}
          </div>
          <div className="mt-auto grid grid-cols-3 gap-2 pt-3 border-t border-slate-800/80 text-center">
            <div>
              <div className="text-[10px] text-slate-500">Phishing</div>
              <div className="text-xs font-mono font-bold text-red-400">{phishingCount}</div>
            </div>
            <div>
              <div className="text-[10px] text-slate-500">Suspicious</div>
              <div className="text-xs font-mono font-bold text-amber-400">{suspiciousCount}</div>
            </div>
            <div>
              <div className="text-[10px] text-slate-500">Safe</div>
              <div className="text-xs font-mono font-bold text-emerald-400">{safeCount}</div>
            </div>
          </div>
        </div>

        {/* Daily Scan Activity */}
        <div className="p-5 rounded-xl bg-slate-900/50 border border-slate-800 flex flex-col lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-cyan-400" />
              Daily Scan Activity & Threat Timeline
            </h3>
            <span className="text-[11px] font-mono text-slate-500">Rolling Database Window</span>
          </div>
          <div className="h-52 w-full">
            {dailyActivityData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={dailyActivityData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="date" stroke="#64748b" fontSize={11} />
                  <YAxis stroke="#64748b" fontSize={11} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#070b14',
                      borderColor: '#1e293b',
                      borderRadius: '8px',
                      fontSize: '12px',
                    }}
                  />
                  <Bar dataKey="phishing" name="Phishing" fill="#ef4444" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="suspicious" name="Suspicious" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="safe" name="Safe" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-slate-500 font-mono">
                No activity records yet. Scan an email to generate timeline data.
              </div>
            )}
          </div>
          <div className="mt-auto flex items-center justify-end gap-4 pt-3 border-t border-slate-800/80 text-[11px] text-slate-400">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-red-500"></span> Phishing
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-amber-500"></span> Suspicious
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-emerald-500"></span> Safe
            </span>
          </div>
        </div>
      </div>

      {/* Bottom Grid: Top Phishing Indicators & Recent Scans */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Most Common Indicators */}
        <div className="p-5 rounded-xl bg-slate-900/50 border border-slate-800 flex flex-col">
          <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider mb-3">
            Top Detected Phishing Vectors
          </h3>
          <div className="space-y-3">
            {topIndicators.length > 0 ? (
              topIndicators.map(([indicator, count], idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-300 truncate max-w-[200px]">{indicator}</span>
                    <span className="text-cyan-400 font-mono font-semibold">{count} hits</span>
                  </div>
                  <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div
                      className="bg-cyan-500 h-full rounded-full"
                      style={{ width: `${Math.min(100, (count / (topIndicators[0][1] || 1)) * 100)}%` }}
                    />
                  </div>
                </div>
              ))
            ) : (
              <div className="text-xs text-slate-500 font-mono py-4">No vector patterns logged.</div>
            )}
          </div>
          <div className="mt-4 pt-3 border-t border-slate-800/80 text-[11px] text-slate-500">
            Vectors normalized via MITRE ATT&CK & PhishGuard ML engine.
          </div>
        </div>

        {/* Recent Scan History */}
        <div className="p-5 rounded-xl bg-slate-900/50 border border-slate-800 lg:col-span-2 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <Clock className="w-4 h-4 text-cyan-400" />
              Recent Threat Detections
            </h3>
            <button
              onClick={() => onNavigate('detection_history')}
              className="text-xs font-mono text-cyan-400 hover:underline flex items-center gap-1"
            >
              View Full History <ExternalLink className="w-3 h-3" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-500 font-mono text-[11px]">
                  <th className="pb-2 font-medium">TYPE</th>
                  <th className="pb-2 font-medium">TARGET / SUBJECT</th>
                  <th className="pb-2 font-medium">VERDICT</th>
                  <th className="pb-2 font-medium">RISK SCORE</th>
                  <th className="pb-2 font-medium">TIMESTAMP</th>
                  <th className="pb-2 font-medium text-right">ACTION</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {scans.slice(0, 5).map((scan) => (
                  <tr key={scan.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-2.5 font-mono text-[11px]">
                      <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 uppercase">
                        {scan.scanType}
                      </span>
                    </td>
                    <td className="py-2.5 max-w-[240px] truncate font-medium text-slate-200">
                      {scan.target || scan.subject || 'Untitled Incident'}
                    </td>
                    <td className="py-2.5">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold font-mono ${
                          scan.classification === 'Phishing'
                            ? 'bg-red-500/20 text-red-300 border border-red-500/30'
                            : scan.classification === 'Suspicious'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        }`}
                      >
                        {scan.classification}
                      </span>
                    </td>
                    <td className="py-2.5 font-mono">
                      <span
                        className={`font-bold ${
                          scan.riskScore >= 70
                            ? 'text-red-400'
                            : scan.riskScore >= 35
                            ? 'text-amber-400'
                            : 'text-emerald-400'
                        }`}
                      >
                        {scan.riskScore}/100
                      </span>
                    </td>
                    <td className="py-2.5 text-slate-400 text-[11px] font-mono">
                      {new Date(scan.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </td>
                    <td className="py-2.5 text-right">
                      <button
                        onClick={() => onNavigate('threat_explanation', scan.id)}
                        className="text-cyan-400 hover:text-cyan-300 font-mono text-[11px] underline"
                      >
                        Explain AI
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
