import React, { useState } from 'react';
import {
  Link2,
  AlertTriangle,
  ShieldCheck,
  ShieldAlert,
  AlertOctagon,
  Globe,
  Radio,
  ExternalLink,
  Loader2,
  CheckCircle2,
  Copy,
  Info,
} from 'lucide-react';
import { UrlScanResult, ScanRecord } from '../types';
import { saveScanRecord, logSecurityAudit } from '../services/dataService';
import { useAuth } from '../context/AuthContext';
import { PageId } from '../components/Sidebar';

interface UrlScannerProps {
  onScanSaved: (scan: ScanRecord) => void;
  onNavigate: (page: PageId, targetScanId?: string) => void;
}

export const UrlScanner: React.FC<UrlScannerProps> = ({ onScanSaved, onNavigate }) => {
  const { user } = useAuth();
  const [urlsInput, setUrlsInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [scanResults, setScanResults] = useState<UrlScanResult[]>([]);
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);

  const sampleUrls = [
    'https://micros0ft-account-verify.xyz/auth/login?user=admin',
    'http://185.220.101.5/banking/chase/verify.php',
    'https://bit.ly/3xSecSecure',
    'https://www.paypal.com.account-update.info/webscr',
    'https://accounts.google.com/signin/v2/identifier',
  ];

  const handleScan = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const rawList = urlsInput
      .split('\n')
      .map((u) => u.trim())
      .filter((u) => u.length > 0);

    if (rawList.length === 0) {
      setError('Please enter at least one URL to scan.');
      return;
    }

    setLoading(true);
    setError(null);
    setScanResults([]);

    try {
      const response = await fetch('/api/v1/urls/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ urls: rawList }),
      });

      if (!response.ok) {
        throw new Error('URL scan failed: ' + response.statusText);
      }

      const data = await response.json();
      const results: UrlScanResult[] = data.results || [];
      setScanResults(results);

      // Save each to Firestore
      for (const res of results) {
        const scanRecord: Omit<ScanRecord, 'id'> = {
          userId: user?.uid || 'guest-analyst',
          userEmail: user?.email || 'guest@phishguard.internal',
          scanType: 'url',
          target: res.url,
          classification: res.classification === 'High Risk' || res.classification === 'Critical' ? 'Phishing' : res.classification === 'Suspicious' ? 'Suspicious' : 'Safe',
          riskScore: res.riskScore,
          confidence: 95,
          evidenceSummary: res.indicators.join('; ') || 'No hostile indicators detected in URL syntax or reputation feeds.',
          recommendedAction: res.recommendation,
          aiExplanation: `URL evaluated for domain spoofing, bare IP usage, path keywords, and threat feeds. Verdict: ${res.classification}.`,
          status: res.riskScore >= 70 ? 'quarantined' : 'analyzed',
          createdAt: new Date().toISOString(),
        };

        const savedId = await saveScanRecord(scanRecord);
        onScanSaved({ ...scanRecord, id: savedId });
      }

      await logSecurityAudit(
        user?.uid || 'guest-analyst',
        user?.email || 'guest@phishguard.internal',
        'URL_BATCH_SCAN',
        `Scanned ${results.length} URLs for malicious infrastructure`
      );
    } catch (err: any) {
      setError(err.message || 'Failed to scan URLs.');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedUrl(text);
    setTimeout(() => setCopiedUrl(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-900">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight font-mono flex items-center gap-2">
            <Link2 className="w-5 h-5 text-cyan-400" />
            URL Threat Intelligence & Lookalike Scanner
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Detect bare IP hosting, punycode spoofing, URL shorteners, fake login directories, and live reputation feeds.
          </p>
        </div>
      </div>

      {/* Safety Notice */}
      <div className="p-3.5 rounded-xl bg-cyan-950/20 border border-cyan-800/30 text-cyan-300 text-xs flex items-center gap-3 font-mono">
        <Info className="w-4 h-4 text-cyan-400 shrink-0" />
        <span>
          SAFE ISOLATION POLICY: Submitted links are analyzed strictly via headless backend parsers. Links are never auto-executed or followed into untrusted redirects.
        </span>
      </div>

      {/* Input section */}
      <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <label className="text-xs font-mono text-slate-300 font-semibold">
            ENTER URLS TO SCAN (ONE PER LINE)
          </label>
          <div className="flex items-center gap-2 text-[11px] text-slate-400">
            <span>Try sample:</span>
            <button
              type="button"
              onClick={() => setUrlsInput(sampleUrls.join('\n'))}
              className="text-cyan-400 hover:underline font-mono"
            >
              Load 5 High-Risk Test URLs
            </button>
          </div>
        </div>

        <textarea
          rows={4}
          value={urlsInput}
          onChange={(e) => setUrlsInput(e.target.value)}
          placeholder="https://example-phishing-login.com/auth&#10;http://185.220.101.5/login&#10;https://bit.ly/suspicious-shortlink"
          className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg p-3 text-xs text-slate-200 placeholder-slate-600 font-mono outline-none resize-y"
        />

        {error && (
          <div className="p-3 rounded-lg bg-red-950/40 border border-red-900/50 text-red-300 text-xs flex items-center gap-2">
            <AlertOctagon className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <button
          onClick={handleScan}
          disabled={loading || !urlsInput.trim()}
          className="w-full sm:w-auto px-6 py-2.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-50 text-slate-950 font-bold text-xs tracking-wide shadow-lg shadow-cyan-500/20 transition-all flex items-center justify-center gap-2 active:scale-98"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Inspecting Domain Infrastructure & VirusTotal Feeds...
            </>
          ) : (
            <>
              <Radio className="w-4 h-4" />
              Scan URLs & Lookalikes
            </>
          )}
        </button>
      </div>

      {/* Scan Results */}
      {scanResults.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-sm font-mono font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
            <span>Analysis Results ({scanResults.length})</span>
          </h3>

          <div className="space-y-4">
            {scanResults.map((result, idx) => (
              <div
                key={idx}
                className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-4 hover:border-slate-700 transition-colors"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
                  <div className="flex items-center gap-2.5 max-w-xl">
                    <div
                      className={`p-2 rounded-lg font-mono font-bold ${
                        result.classification === 'Critical' || result.classification === 'High Risk'
                          ? 'bg-red-500/10 text-red-400 border border-red-500/30'
                          : result.classification === 'Suspicious'
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                          : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                      }`}
                    >
                      {result.classification === 'Critical' && <AlertOctagon className="w-5 h-5" />}
                      {result.classification === 'High Risk' && <ShieldAlert className="w-5 h-5" />}
                      {result.classification === 'Suspicious' && <AlertTriangle className="w-5 h-5" />}
                      {result.classification === 'Safe' && <ShieldCheck className="w-5 h-5" />}
                    </div>
                    <div>
                      <div className="text-xs font-mono font-bold text-slate-200 truncate select-all">
                        {result.url}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                        Domain: <span className="text-cyan-400">{result.domain}</span> • Protocol: {result.protocol}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="text-right font-mono">
                      <div
                        className={`text-lg font-bold ${
                          result.riskScore >= 70
                            ? 'text-red-400'
                            : result.riskScore >= 35
                            ? 'text-amber-400'
                            : 'text-emerald-400'
                        }`}
                      >
                        {result.riskScore}/100
                      </div>
                      <div className="text-[10px] text-slate-500 uppercase">{result.classification}</div>
                    </div>

                    <button
                      onClick={() => copyToClipboard(result.url)}
                      className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
                      title="Copy URL"
                    >
                      {copiedUrl === result.url ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Detected Indicators */}
                <div>
                  <div className="text-[11px] font-mono font-semibold text-slate-400 uppercase mb-2">
                    Detected Indicators:
                  </div>
                  {result.indicators.length > 0 ? (
                    <div className="space-y-1.5">
                      {result.indicators.map((ind, i) => (
                        <div
                          key={i}
                          className="px-3 py-1.5 rounded-lg bg-slate-950 text-xs text-slate-300 font-mono flex items-center gap-2 border border-slate-850"
                        >
                          <span className="w-1.5 h-1.5 rounded-full bg-red-400 shrink-0"></span>
                          <span>{ind}</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-xs text-emerald-400 font-mono flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" />
                      Clean syntax structure. No known credential harvesting directories detected.
                    </div>
                  )}
                </div>

                {/* Threat Feeds & Recommendations */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
                  <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                    <span className="text-[10px] font-mono text-slate-500 uppercase block mb-1">
                      Threat Intelligence Feeds
                    </span>
                    <div className="flex items-center justify-between text-slate-300">
                      <span>VirusTotal Flagged Engines:</span>
                      <span className="font-mono font-bold text-red-400">
                        {result.reputation.virustotalDetections} / {result.reputation.virustotalTotalEngines}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-slate-300 mt-1">
                      <span>Google Safe Browsing:</span>
                      <span
                        className={`font-mono font-bold ${
                          result.reputation.googleSafeBrowsing === 'CLEAN'
                            ? 'text-emerald-400'
                            : 'text-red-400'
                        }`}
                      >
                        {result.reputation.googleSafeBrowsing}
                      </span>
                    </div>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                    <span className="text-[10px] font-mono text-cyan-400 uppercase block mb-1">
                      Actionable Containment
                    </span>
                    <p className="text-slate-300 text-xs">{result.recommendation}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
