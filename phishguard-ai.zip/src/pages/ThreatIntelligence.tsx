import React, { useState } from 'react';
import {
  Radio,
  Plus,
  Trash2,
  ExternalLink,
  ShieldAlert,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Globe,
  Server,
  Hash,
  Link,
  Loader2,
} from 'lucide-react';
import { ThreatIOC } from '../types';
import { addThreatIndicator, deleteThreatIndicator, logSecurityAudit } from '../services/dataService';
import { useAuth } from '../context/AuthContext';

interface ThreatIntelligenceProps {
  iocs: ThreatIOC[];
  onRefresh: () => void;
}

export const ThreatIntelligence: React.FC<ThreatIntelligenceProps> = ({ iocs, onRefresh }) => {
  const { user, isAnalyst } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');

  // New IOC Modal / Form State
  const [showAddModal, setShowAddModal] = useState(false);
  const [newIndicator, setNewIndicator] = useState('');
  const [newType, setNewType] = useState<'url' | 'domain' | 'ip' | 'hash'>('domain');
  const [newThreatType, setNewThreatType] = useState('Credential Harvesting / Phishing');
  const [newSource, setNewSource] = useState('Analyst Manual Submission');
  const [newScore, setNewScore] = useState(90);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const filteredIocs = iocs.filter((ioc) => {
    const matchesSearch =
      (ioc.indicator || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (ioc.threatType || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (ioc.source || '').toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = typeFilter === 'all' || ioc.type === typeFilter;
    return matchesSearch && matchesType;
  });

  const handleAddIoc = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newIndicator.trim()) return;
    setIsSubmitting(true);
    try {
      await addThreatIndicator({
        indicator: newIndicator.trim(),
        type: newType,
        threatType: newThreatType,
        source: newSource,
        reputationScore: newScore,
        status: 'active',
        lastSeen: new Date().toISOString(),
        addedBy: user?.displayName || user?.email || 'SOC Analyst',
      });

      await logSecurityAudit(
        user?.uid || 'analyst',
        user?.email || 'analyst@phishguard.internal',
        'IOC_ADDED',
        `Added ${newType} indicator "${newIndicator}" to threat intelligence database`
      );

      setNewIndicator('');
      setShowAddModal(false);
      onRefresh();
    } catch (err: any) {
      alert('Failed to add IOC: ' + err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string, indicator: string) => {
    if (!confirm(`Are you sure you want to remove indicator "${indicator}"?`)) return;
    try {
      await deleteThreatIndicator(id);
      await logSecurityAudit(
        user?.uid || 'analyst',
        user?.email || 'analyst@phishguard.internal',
        'IOC_REMOVED',
        `Removed indicator ${id} (${indicator}) from IOC registry`,
        id
      );
      onRefresh();
    } catch (err: any) {
      alert('Delete failed: ' + err.message);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-900">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight font-mono flex items-center gap-2">
            <Radio className="w-5 h-5 text-cyan-400" />
            Threat Intelligence & Global IOC Indicators
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Synchronized threat repository: VirusTotal telemetry, Google Safe Browsing, and local SOC detections.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-md transition-all flex items-center gap-1.5 active:scale-95"
        >
          <Plus className="w-4 h-4" />
          Add Threat Indicator (IOC)
        </button>
      </div>

      {/* Integration Status Badges */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></div>
            <div>
              <div className="text-xs font-semibold text-white font-mono">VirusTotal API Feed</div>
              <div className="text-[10px] text-slate-400">72 Anti-Malware Engines</div>
            </div>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            CONNECTED
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></div>
            <div>
              <div className="text-xs font-semibold text-white font-mono">Google Safe Browsing</div>
              <div className="text-[10px] text-slate-400">Real-time Phishing Radar</div>
            </div>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            CONNECTED
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-2.5 h-2.5 rounded-full bg-cyan-400"></div>
            <div>
              <div className="text-xs font-semibold text-white font-mono">Local IOC Database</div>
              <div className="text-[10px] text-slate-400">{iocs.length} Active Signatures</div>
            </div>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            SYNCED
          </span>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search indicators, domains, IPs, hashes..."
            className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-600 outline-none"
          />
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
          <span>Type:</span>
          {['all', 'domain', 'url', 'ip', 'hash'].map((t) => (
            <button
              key={t}
              onClick={() => setTypeFilter(t)}
              className={`px-2.5 py-1 rounded text-xs uppercase ${
                typeFilter === t
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold'
                  : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* IOC Table */}
      <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="border-b border-slate-800 text-slate-500 font-mono text-[11px]">
              <th className="pb-3 font-medium">TYPE</th>
              <th className="pb-3 font-medium">INDICATOR (IOC)</th>
              <th className="pb-3 font-medium">THREAT CLASSIFICATION</th>
              <th className="pb-3 font-medium">SOURCE ATTRIBUTION</th>
              <th className="pb-3 font-medium">CONFIDENCE</th>
              <th className="pb-3 font-medium">LAST DETECTED</th>
              <th className="pb-3 font-medium text-right">ACTION</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono">
            {filteredIocs.length > 0 ? (
              filteredIocs.map((ioc) => (
                <tr key={ioc.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 text-[11px]">
                    <span className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-300 uppercase flex items-center gap-1 w-fit">
                      {ioc.type === 'domain' && <Globe className="w-3 h-3 text-cyan-400" />}
                      {ioc.type === 'ip' && <Server className="w-3 h-3 text-blue-400" />}
                      {ioc.type === 'url' && <Link className="w-3 h-3 text-amber-400" />}
                      {ioc.type === 'hash' && <Hash className="w-3 h-3 text-purple-400" />}
                      {ioc.type}
                    </span>
                  </td>
                  <td className="py-3 font-bold text-slate-200 select-all max-w-[260px] truncate">
                    {ioc.indicator}
                  </td>
                  <td className="py-3 text-red-400 text-[11px] font-semibold">{ioc.threatType}</td>
                  <td className="py-3 text-slate-400 text-[11px]">{ioc.source}</td>
                  <td className="py-3 text-cyan-400 font-bold">{ioc.reputationScore}%</td>
                  <td className="py-3 text-slate-500 text-[11px]">
                    {new Date(ioc.lastSeen).toLocaleDateString()}
                  </td>
                  <td className="py-3 text-right">
                    <button
                      onClick={() => handleDelete(ioc.id, ioc.indicator)}
                      className="p-1.5 rounded hover:bg-slate-800 text-slate-500 hover:text-red-400 transition-colors"
                      title="Delete Indicator"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={7} className="py-8 text-center text-xs text-slate-500">
                  No threat indicators found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#090d18] border border-cyan-900/60 rounded-xl p-6 max-w-md w-full space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
              <Plus className="w-4 h-4 text-cyan-400" />
              Add Threat Indicator (IOC)
            </h3>

            <form onSubmit={handleAddIoc} className="space-y-3">
              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">IOC TYPE</label>
                <select
                  value={newType}
                  onChange={(e: any) => setNewType(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 font-mono outline-none"
                >
                  <option value="domain">Domain Name</option>
                  <option value="url">URL Endpoint</option>
                  <option value="ip">IPv4 Address</option>
                  <option value="hash">File SHA256 Hash</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">INDICATOR STRING</label>
                <input
                  type="text"
                  required
                  value={newIndicator}
                  onChange={(e) => setNewIndicator(e.target.value)}
                  placeholder="e.g. evil-login-chase.xyz or 185.220.101.5"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg px-3 py-2 text-xs text-slate-200 font-mono outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">THREAT CATEGORY</label>
                <input
                  type="text"
                  value={newThreatType}
                  onChange={(e) => setNewThreatType(e.target.value)}
                  placeholder="e.g. Credential Harvesting, Banking Trojan"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 font-mono outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">SOURCE ATTRIBUTION</label>
                <input
                  type="text"
                  value={newSource}
                  onChange={(e) => setNewSource(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 font-mono outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs"
                >
                  {isSubmitting ? 'Submitting...' : 'Register IOC'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
