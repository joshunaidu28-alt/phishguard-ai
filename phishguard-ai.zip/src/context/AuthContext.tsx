import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db, loginWithGoogle, logoutUser, handleFirestoreError, OperationType } from '../firebase';
import { UserProfile, UserRole } from '../types';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  role: UserRole;
  isAdmin: boolean;
  isAnalyst: boolean;
  loading: boolean;
  signIn: () => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  profile: null,
  role: 'VIEWER',
  isAdmin: false,
  isAnalyst: false,
  loading: true,
  signIn: async () => {},
  signOut: async () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [role, setRole] = useState<UserRole>('VIEWER');
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        try {
          const userDocRef = doc(db, 'users', currentUser.uid);
          const snap = await getDoc(userDocRef);
          const isBootstrapAdmin = currentUser.email === 'yadavlathish6@gmail.com';

          if (snap.exists()) {
            const data = snap.data() as UserProfile;
            setProfile(data);
            setRole(isBootstrapAdmin ? 'ADMIN' : data.role || 'SECURITY_ANALYST');
          } else {
            // New user registration
            const assignedRole: UserRole = isBootstrapAdmin ? 'ADMIN' : 'SECURITY_ANALYST';
            const newProfile: UserProfile = {
              uid: currentUser.uid,
              email: currentUser.email || 'user@phishguard.internal',
              displayName: currentUser.displayName || currentUser.email?.split('@')[0] || 'Security Officer',
              role: assignedRole,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            };

            await setDoc(userDocRef, newProfile);
            setProfile(newProfile);
            setRole(assignedRole);

            // Also register in admins collection if bootstrap admin
            if (isBootstrapAdmin) {
              const adminDocRef = doc(db, 'admins', currentUser.uid);
              await setDoc(adminDocRef, {
                email: currentUser.email,
                assignedAt: new Date().toISOString(),
              });
            }
          }
        } catch (err) {
          console.error('Error synchronizing user profile:', err);
          handleFirestoreError(err, OperationType.GET, `users/${currentUser.uid}`);
        }
      } else {
        setProfile(null);
        setRole('VIEWER');
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signIn = async () => {
    try {
      await loginWithGoogle();
    } catch (err) {
      console.error('Sign-in failed:', err);
      throw err;
    }
  };

  const signOut = async () => {
    try {
      await logoutUser();
    } catch (err) {
      console.error('Sign-out failed:', err);
      throw err;
    }
  };

  const isAdmin = role === 'ADMIN';
  const isAnalyst = role === 'ADMIN' || role === 'SECURITY_ANALYST';

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        role,
        isAdmin,
        isAnalyst,
        loading,
        signIn,
        signOut,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
