export type ThreatClassification = 'Safe' | 'Suspicious' | 'Phishing';
export type RiskLevel = 'low' | 'medium' | 'high' | 'critical';
export type UserRole = 'ADMIN' | 'SECURITY_ANALYST' | 'VIEWER';
export type ScanType = 'email' | 'url' | 'header' | 'domain';

export interface ThreatIndicatorItem {
  id: string;
  category: string;
  description: string;
  severity: RiskLevel;
}

export interface ScanRecord {
  id: string;
  userId: string;
  userEmail: string;
  scanType: ScanType;
  target: string;
  sender?: string;
  recipient?: string;
  subject?: string;
  classification: ThreatClassification;
  riskScore: number;
  confidence: number;
  evidenceSummary: string;
  recommendedAction: string;
  aiExplanation: string;
  status: 'analyzed' | 'quarantined' | 'released' | 'dismissed';
  createdAt: string;
  indicators?: ThreatIndicatorItem[];
  tactics?: string[];
  extractedUrls?: string[];
  parsedHeaders?: Record<string, string>;
}

export interface QuarantineRecord {
  id: string;
  scanId: string;
  userId: string;
  target: string;
  sender?: string;
  riskScore: number;
  status: 'pending' | 'approved' | 'rejected' | 'released';
  analystNotes?: string;
  reviewedBy?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface ThreatIOC {
  id: string;
  indicator: string;
  type: 'url' | 'domain' | 'ip' | 'hash';
  threatType: string;
  source: string;
  reputationScore: number;
  status: 'active' | 'benign' | 'under_review';
  lastSeen: string;
  addedBy?: string;
}

export interface AuditLogEntry {
  id: string;
  userId: string;
  userEmail: string;
  action: string;
  targetId?: string;
  details: string;
  timestamp: string;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  createdAt: string;
  updatedAt: string;
}

export interface EmailScanResult {
  scanId: string;
  timestamp: string;
  metadata: {
    from: string;
    to: string;
    subject: string;
    urlsFound: number;
    headersParsed: number;
  };
  classification: ThreatClassification;
  riskScore: number;
  confidence: number;
  tactics: string[];
  indicators: ThreatIndicatorItem[];
  extractedUrls: string[];
  parsedHeaders: Record<string, string>;
  recommendedAction: string;
  aiExplanation: string;
  mlSignals?: {
    nlpUrgencyWeight: number;
    senderReputationWeight: number;
    authStatus: string;
  };
}

export interface UrlScanResult {
  url: string;
  domain: string;
  protocol: string;
  path: string;
  valid: boolean;
  classification: 'Safe' | 'Suspicious' | 'High Risk' | 'Critical';
  riskScore: number;
  indicators: string[];
  reputation: {
    virustotalDetections: number;
    virustotalTotalEngines: number;
    googleSafeBrowsing: string;
    threatCategories: string[];
  };
  recommendation: string;
  analyzedAt: string;
}

export interface HeaderAnalysisResult {
  analyzedAt: string;
  summary: {
    from: string;
    returnPath: string;
    replyTo: string;
    messageId: string;
  };
  authentication: {
    spf: { status: 'PASS' | 'FAIL' | 'NONE'; details: string };
    dkim: { status: 'PASS' | 'FAIL' | 'NONE'; details: string };
    dmarc: { status: 'PASS' | 'FAIL' | 'NONE'; details: string };
  };
  anomalies: string[];
  hopsCount: number;
  hops: Array<{
    hopNumber: number;
    raw: string;
    fromServer: string;
    byServer: string;
  }>;
  riskScore: number;
  verdict: string;
}

export interface DomainAnalysisResult {
  domain: string;
  analyzedAt: string;
  dns: {
    aRecords: string[];
    mxRecords: Array<{ host: string; priority: number }>;
    txtRecords: string[];
    nsRecords: string[];
    dmarcRecord: string;
    spfRecord: string;
  };
  lookalikeAnalysis: {
    isSpoofAttempt: boolean;
    targetBrand: string | null;
    notes: string;
  };
  reputationScore: number;
  riskScore: number;
  classification: string;
  whoisEstimated: {
    registeredDaysAgo: number;
    privacyProtected: boolean;
  };
  threatFactors: string[];
}
