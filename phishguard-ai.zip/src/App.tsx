import React, { useState, useEffect } from 'react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { Sidebar, PageId } from './components/Sidebar';
import { ChatDrawer } from './components/ChatDrawer';

// Pages
import { Dashboard } from './pages/Dashboard';
import { EmailScanner } from './pages/EmailScanner';
import { UrlScanner } from './pages/UrlScanner';
import { HeaderAnalyzer } from './pages/HeaderAnalyzer';
import { DomainIntelligence } from './pages/DomainIntelligence';
import { ThreatExplanation } from './pages/ThreatExplanation';
import { DetectionHistory } from './pages/DetectionHistory';
import { QuarantineCenter } from './pages/QuarantineCenter';
import { ThreatIntelligence } from './pages/ThreatIntelligence';
import { AnalyticsReports } from './pages/AnalyticsReports';
import { UserManagement } from './pages/UserManagement';
import { AuditLogs } from './pages/AuditLogs';
import { Integrations } from './pages/Integrations';
import { Settings } from './pages/Settings';

// Types and Seed Data
import { ScanRecord, QuarantineRecord, ThreatIOC, AuditLogEntry } from './types';
import {
  INITIAL_DEMO_SCANS,
  INITIAL_DEMO_QUARANTINE,
  INITIAL_DEMO_IOCS,
  INITIAL_DEMO_AUDIT,
} from './services/seedData';

function AppContent() {
  const { user } = useAuth();
  const [activePage, setActivePage] = useState<PageId>('dashboard');
  const [selectedScanId, setSelectedScanId] = useState<string | undefined>();
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [activeChatContext, setActiveChatContext] = useState<any>(null);

  // Core application telemetry states
  const [scans, setScans] = useState<ScanRecord[]>(INITIAL_DEMO_SCANS);
  const [quarantine, setQuarantine] = useState<QuarantineRecord[]>(INITIAL_DEMO_QUARANTINE);
  const [iocs, setIocs] = useState<ThreatIOC[]>(INITIAL_DEMO_IOCS);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(INITIAL_DEMO_AUDIT);

  // Firestore Live Listeners with mandatory error handling
  useEffect(() => {
    // 1. Scans listener
    const scansPath = 'scans';
    const unsubScans = onSnapshot(
      collection(db, scansPath),
      (snapshot) => {
        if (!snapshot.empty) {
          const liveScans: ScanRecord[] = [];
          snapshot.forEach((doc) => {
            liveScans.push({ ...doc.data(), id: doc.id } as ScanRecord);
          });
          // Merge with initial demo scans if needed so records are always comprehensive
          const existingIds = new Set(liveScans.map((s) => s.id));
          const merged = [...liveScans, ...INITIAL_DEMO_SCANS.filter((s) => !existingIds.has(s.id))];
          merged.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
          setScans(merged);
        }
      },
      (error) => {
        console.warn('Scans onSnapshot error:', error);
        handleFirestoreError(error, OperationType.GET, scansPath);
      }
    );

    // 2. Quarantine listener
    const quarantinePath = 'quarantine';
    const unsubQuarantine = onSnapshot(
      collection(db, quarantinePath),
      (snapshot) => {
        if (!snapshot.empty) {
          const liveQ: QuarantineRecord[] = [];
          snapshot.forEach((doc) => {
            liveQ.push({ ...doc.data(), id: doc.id } as QuarantineRecord);
          });
          const existingIds = new Set(liveQ.map((q) => q.id));
          const merged = [...liveQ, ...INITIAL_DEMO_QUARANTINE.filter((q) => !existingIds.has(q.id))];
          merged.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
          setQuarantine(merged);
        }
      },
      (error) => {
        console.warn('Quarantine onSnapshot error:', error);
        handleFirestoreError(error, OperationType.GET, quarantinePath);
      }
    );

    // 3. IOCs listener
    const iocPath = 'threat_indicators';
    const unsubIocs = onSnapshot(
      collection(db, iocPath),
      (snapshot) => {
        if (!snapshot.empty) {
          const liveIocs: ThreatIOC[] = [];
          snapshot.forEach((doc) => {
            liveIocs.push({ ...doc.data(), id: doc.id } as ThreatIOC);
          });
          const existingIds = new Set(liveIocs.map((i) => i.id));
          const merged = [...liveIocs, ...INITIAL_DEMO_IOCS.filter((i) => !existingIds.has(i.id))];
          setIocs(merged);
        }
      },
      (error) => {
        console.warn('Threat IOC onSnapshot error:', error);
        handleFirestoreError(error, OperationType.GET, iocPath);
      }
    );

    // 4. Audit logs listener
    const auditPath = 'audit_logs';
    const unsubAudit = onSnapshot(
      collection(db, auditPath),
      (snapshot) => {
        if (!snapshot.empty) {
          const liveLogs: AuditLogEntry[] = [];
          snapshot.forEach((doc) => {
            liveLogs.push({ ...doc.data(), id: doc.id } as AuditLogEntry);
          });
          const existingIds = new Set(liveLogs.map((l) => l.id));
          const merged = [...liveLogs, ...INITIAL_DEMO_AUDIT.filter((l) => !existingIds.has(l.id))];
          merged.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
          setAuditLogs(merged);
        }
      },
      (error) => {
        console.warn('Audit logs onSnapshot error:', error);
        handleFirestoreError(error, OperationType.GET, auditPath);
      }
    );

    return () => {
      unsubScans();
      unsubQuarantine();
      unsubIocs();
      unsubAudit();
    };
  }, []);

  const handleScanSaved = (newScan: ScanRecord) => {
    setScans((prev) => [newScan, ...prev.filter((s) => s.id !== newScan.id)]);
  };

  const handleNavigate = (page: PageId, scanId?: string) => {
    if (scanId) setSelectedScanId(scanId);
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenChatWithScan = (scan: ScanRecord) => {
    setActiveChatContext(scan);
    setIsChatOpen(true);
  };

  const pendingQuarantinesCount = quarantine.filter((q) => q.status === 'pending').length;
  const highRiskThreatsCount = scans.filter((s) => s.riskScore >= 70).length;

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      <Navbar
        onOpenChat={() => {
          setActiveChatContext(null);
          setIsChatOpen(true);
        }}
        activeIncidentsCount={highRiskThreatsCount}
      />

      <div className="flex-1 flex overflow-hidden">
        <Sidebar
          activePage={activePage}
          onSelectPage={handleNavigate}
          pendingQuarantineCount={pendingQuarantinesCount}
        />

        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-gradient-to-b from-[#070b14] via-[#090e1c] to-[#070b14]">
          {activePage === 'dashboard' && (
            <Dashboard scans={scans} quarantine={quarantine} onNavigate={handleNavigate} />
          )}

          {activePage === 'email_scanner' && (
            <EmailScanner onScanSaved={handleScanSaved} onNavigate={handleNavigate} />
          )}

          {activePage === 'url_scanner' && (
            <UrlScanner onScanSaved={handleScanSaved} onNavigate={handleNavigate} />
          )}

          {activePage === 'header_analyzer' && <HeaderAnalyzer />}

          {activePage === 'domain_intel' && <DomainIntelligence />}

          {activePage === 'threat_explanation' && (
            <ThreatExplanation
              scans={scans}
              selectedScanId={selectedScanId}
              onOpenChatWithScan={handleOpenChatWithScan}
            />
          )}

          {activePage === 'detection_history' && (
            <DetectionHistory scans={scans} onNavigate={handleNavigate} />
          )}

          {activePage === 'quarantine' && (
            <QuarantineCenter
              quarantine={quarantine}
              onRefresh={() => {
                // Trigger local update if needed
              }}
            />
          )}

          {activePage === 'threat_intel' && (
            <ThreatIntelligence
              iocs={iocs}
              onRefresh={() => {
                // Trigger local update if needed
              }}
            />
          )}

          {activePage === 'analytics' && <AnalyticsReports scans={scans} />}

          {activePage === 'user_management' && <UserManagement />}

          {activePage === 'audit_logs' && <AuditLogs logs={auditLogs} />}

          {activePage === 'integrations' && <Integrations />}

          {activePage === 'settings' && <Settings />}
        </main>
      </div>

      <ChatDrawer
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        activeContext={activeChatContext}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
