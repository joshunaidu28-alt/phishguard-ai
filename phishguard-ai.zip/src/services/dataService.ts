import {
  collection,
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  orderBy,
  limit,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { ScanRecord, QuarantineRecord, ThreatIOC, AuditLogEntry } from '../types';

// Audit Logging Service
export async function logSecurityAudit(
  userId: string,
  userEmail: string,
  action: string,
  details: string,
  targetId?: string
) {
  const logId = 'LOG-' + Math.random().toString(36).substring(2, 10).toUpperCase();
  const path = `audit_logs/${logId}`;
  try {
    const entry: AuditLogEntry = {
      id: logId,
      userId,
      userEmail,
      action,
      details,
      targetId: targetId || '',
      timestamp: new Date().toISOString(),
    };
    await setDoc(doc(db, 'audit_logs', logId), entry);
  } catch (err) {
    console.error('Failed to write audit log:', err);
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

// Scans Persistence
export async function saveScanRecord(scan: Omit<ScanRecord, 'id'>): Promise<string> {
  const scanId = 'SCN-' + Math.random().toString(36).substring(2, 10).toUpperCase();
  const path = `scans/${scanId}`;
  try {
    const fullRecord: ScanRecord = {
      ...scan,
      id: scanId,
    };
    await setDoc(doc(db, 'scans', scanId), fullRecord);
    return scanId;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
    throw err;
  }
}

// Quarantine Actions
export async function createQuarantineRequest(
  userId: string,
  scanId: string,
  target: string,
  sender: string,
  riskScore: number,
  notes: string = ''
): Promise<string> {
  const qId = 'QRN-' + Math.random().toString(36).substring(2, 10).toUpperCase();
  const path = `quarantine/${qId}`;
  try {
    const record: QuarantineRecord = {
      id: qId,
      scanId,
      userId,
      target,
      sender,
      riskScore,
      status: 'pending',
      analystNotes: notes,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await setDoc(doc(db, 'quarantine', qId), record);
    return qId;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
    throw err;
  }
}

export async function updateQuarantineStatus(
  quarantineId: string,
  status: 'approved' | 'rejected' | 'released',
  reviewer: string,
  notes?: string
) {
  const path = `quarantine/${quarantineId}`;
  try {
    const docRef = doc(db, 'quarantine', quarantineId);
    await updateDoc(docRef, {
      status,
      reviewedBy: reviewer,
      updatedAt: new Date().toISOString(),
      ...(notes ? { analystNotes: notes } : {}),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
    throw err;
  }
}

export async function bulkUpdateQuarantineStatus(
  quarantineIds: string[],
  status: 'approved' | 'rejected' | 'released',
  reviewer: string,
  notes?: string
) {
  await Promise.all(
    quarantineIds.map((id) => updateQuarantineStatus(id, status, reviewer, notes))
  );
}

// Threat IOCs
export async function addThreatIndicator(ioc: Omit<ThreatIOC, 'id'>): Promise<string> {
  const iocId = 'IOC-' + Math.random().toString(36).substring(2, 10).toUpperCase();
  const path = `threat_indicators/${iocId}`;
  try {
    const record: ThreatIOC = {
      ...ioc,
      id: iocId,
    };
    await setDoc(doc(db, 'threat_indicators', iocId), record);
    return iocId;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
    throw err;
  }
}

export async function deleteThreatIndicator(iocId: string) {
  const path = `threat_indicators/${iocId}`;
  try {
    await deleteDoc(doc(db, 'threat_indicators', iocId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
    throw err;
  }
}
