import test from 'node:test';
import assert from 'node:assert/strict';

// Test homoglyph and lookalike detection
const MONITORED_DOMAINS = [
  'google.com', 'microsoft.com', 'apple.com', 'amazon.com', 'paypal.com',
  'chase.com', 'bankofamerica.com'
];

function checkLookalike(domain: string): { isLookalike: boolean; targetBrand?: string; reason?: string } {
  const cleanDomain = domain.toLowerCase().replace(/^www\./, '');
  if (cleanDomain.startsWith('xn--')) {
    return { isLookalike: true, reason: 'Punycode internationalized domain (IDN homograph candidate)' };
  }
  for (const brand of MONITORED_DOMAINS) {
    if (cleanDomain === brand || cleanDomain.endsWith(`.${brand}`)) {
      continue;
    }
    const brandName = brand.split('.')[0];
    if (cleanDomain.includes(brandName)) {
      return { isLookalike: true, targetBrand: brand, reason: `Target brand name "${brandName}" embedded in untrusted domain` };
    }
    const normalized = cleanDomain.replace(/0/g, 'o').replace(/1/g, 'l').replace(/vv/g, 'w').replace(/rn/g, 'm');
    if (normalized.includes(brandName)) {
      return { isLookalike: true, targetBrand: brand, reason: `Visual character substitution spoofing "${brand}"` };
    }
  }
  return { isLookalike: false };
}

function parseHeaders(raw: string): Record<string, string> {
  const lines = raw.split(/\r?\n/);
  const headers: Record<string, string> = {};
  for (const line of lines) {
    const match = line.match(/^([^:]+):\s*(.*)$/);
    if (match) {
      headers[match[1].toLowerCase()] = match[2].trim();
    }
  }
  return headers;
}

test('Lookalike Detector identifies homoglyph character substitutions', () => {
  const spoofedMicrosoft = checkLookalike('micros0ft-login.xyz');
  assert.equal(spoofedMicrosoft.isLookalike, true);
  assert.equal(spoofedMicrosoft.targetBrand, 'microsoft.com');

  const spoofedGoogle = checkLookalike('g00gle-verify.com');
  assert.equal(spoofedGoogle.isLookalike, true);
  assert.equal(spoofedGoogle.targetBrand, 'google.com');
});

test('Lookalike Detector allows authentic subdomains of legitimate brands', () => {
  const authGoogle = checkLookalike('accounts.google.com');
  assert.equal(authGoogle.isLookalike, false);

  const authMicrosoft = checkLookalike('login.microsoft.com');
  assert.equal(authMicrosoft.isLookalike, false);
});

test('Header Parser extracts envelope and SPF/DKIM authentication results', () => {
  const sample = `From: IT Support <security@spoofed.com>
To: victim@company.com
Reply-To: evil@attacker.ru
Authentication-Results: spf=fail; dkim=fail; dmarc=fail`;

  const parsed = parseHeaders(sample);
  assert.equal(parsed['from'], 'IT Support <security@spoofed.com>');
  assert.equal(parsed['reply-to'], 'evil@attacker.ru');
  assert.match(parsed['authentication-results'], /spf=fail/);
  assert.match(parsed['authentication-results'], /dmarc=fail/);
});

test('Punycode IDN detector flags internationalized domain spoofing', () => {
  const idnDomain = checkLookalike('xn--pple-43d.com'); // Apple spoofing candidate
  assert.equal(idnDomain.isLookalike, true);
  assert.match(idnDomain.reason || '', /Punycode/);
});
