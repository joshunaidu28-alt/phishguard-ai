import React from 'react';
import {
  LayoutDashboard,
  MailCheck,
  Link2,
  FileCode2,
  Globe2,
  BrainCircuit,
  History,
  ArchiveRestore,
  Radio,
  BarChart3,
  Users2,
  ScrollText,
  Sliders,
  PlugZap,
  ChevronRight,
} from 'lucide-react';

export type PageId =
  | 'dashboard'
  | 'email_scanner'
  | 'url_scanner'
  | 'header_analyzer'
  | 'domain_intel'
  | 'threat_explanation'
  | 'detection_history'
  | 'quarantine'
  | 'threat_intel'
  | 'analytics'
  | 'user_management'
  | 'audit_logs'
  | 'integrations'
  | 'settings';

interface SidebarProps {
  activePage: PageId;
  onSelectPage: (page: PageId) => void;
  pendingQuarantineCount: number;
}

interface NavItem {
  id: PageId;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
  count?: number;
}

interface NavGroup {
  group: string;
  items: NavItem[];
}

export const Sidebar: React.FC<SidebarProps> = ({
  activePage,
  onSelectPage,
  pendingQuarantineCount,
}) => {
  const navSections: NavGroup[] = [
    {
      group: 'THREAT DETECTION',
      items: [
        { id: 'dashboard' as PageId, label: 'SOC Dashboard', icon: LayoutDashboard },
        { id: 'email_scanner' as PageId, label: 'Email Scanner', icon: MailCheck, badge: 'AI' },
        { id: 'url_scanner' as PageId, label: 'URL Scanner', icon: Link2 },
        { id: 'header_analyzer' as PageId, label: 'Header Analyzer', icon: FileCode2 },
        { id: 'domain_intel' as PageId, label: 'Domain Intelligence', icon: Globe2 },
      ],
    },
    {
      group: 'ANALYSIS & RESPONSE',
      items: [
        { id: 'threat_explanation' as PageId, label: 'AI Threat Explanation', icon: BrainCircuit },
        { id: 'detection_history' as PageId, label: 'Detection History', icon: History },
        {
          id: 'quarantine' as PageId,
          label: 'Quarantine Center',
          icon: ArchiveRestore,
          count: pendingQuarantineCount > 0 ? pendingQuarantineCount : undefined,
        },
        { id: 'threat_intel' as PageId, label: 'Threat Intelligence', icon: Radio },
        { id: 'analytics' as PageId, label: 'Analytics & Reports', icon: BarChart3 },
      ],
    },
    {
      group: 'GOVERNANCE & CONFIG',
      items: [
        { id: 'user_management' as PageId, label: 'User Management', icon: Users2 },
        { id: 'audit_logs' as PageId, label: 'Audit Logs', icon: ScrollText },
        { id: 'integrations' as PageId, label: 'Integrations', icon: PlugZap },
        { id: 'settings' as PageId, label: 'Settings', icon: Sliders },
      ],
    },
  ];

  return (
    <aside className="w-64 bg-[#070b14] border-r border-slate-900 flex flex-col h-[calc(100vh-4rem)] sticky top-16 shrink-0 select-none overflow-y-auto">
      <div className="py-4 px-3 space-y-6">
        {navSections.map((sec) => (
          <div key={sec.group}>
            <div className="px-3 mb-2 text-[10px] font-mono font-semibold tracking-wider text-slate-500 uppercase">
              {sec.group}
            </div>
            <div className="space-y-1">
              {sec.items.map((item) => {
                const Icon = item.icon;
                const isActive = activePage === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onSelectPage(item.id)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all group ${
                      isActive
                        ? 'bg-gradient-to-r from-cyan-950/80 to-blue-950/40 text-cyan-300 border border-cyan-500/30 shadow-[0_0_12px_rgba(6,182,212,0.15)] font-semibold'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon
                        className={`w-4 h-4 transition-colors ${
                          isActive
                            ? 'text-cyan-400'
                            : 'text-slate-500 group-hover:text-slate-300'
                        }`}
                      />
                      <span>{item.label}</span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {item.badge && (
                        <span className="text-[9px] font-mono font-bold px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                          {item.badge}
                        </span>
                      )}
                      {item.count !== undefined && (
                        <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse">
                          {item.count}
                        </span>
                      )}
                      <ChevronRight
                        className={`w-3 h-3 text-slate-600 transition-transform ${
                          isActive
                            ? 'transform translate-x-0.5 text-cyan-400 opacity-100'
                            : 'opacity-0 group-hover:opacity-100'
                        }`}
                      />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Footer SOC Status */}
      <div className="mt-auto p-3 m-3 rounded-lg bg-slate-900/60 border border-slate-800/80">
        <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 mb-1">
          <span>THREAT LEVEL</span>
          <span className="text-amber-400 font-bold">ELEVATED</span>
        </div>
        <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
          <div className="bg-gradient-to-r from-emerald-500 via-amber-500 to-red-500 w-[68%] h-full"></div>
        </div>
        <div className="mt-2 text-[10px] text-slate-500 flex items-center justify-between font-mono">
          <span>Zero-Day Shield</span>
          <span className="text-emerald-400">ACTIVE</span>
        </div>
      </div>
    </aside>
  );
};
