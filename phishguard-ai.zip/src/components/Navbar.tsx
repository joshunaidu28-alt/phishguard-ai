import React from 'react';
import {
  Shield,
  ShieldAlert,
  Bot,
  User,
  LogOut,
  LogIn,
  Activity,
  Terminal,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface NavbarProps {
  onOpenChat: () => void;
  activeIncidentsCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenChat, activeIncidentsCount }) => {
  const { user, profile, role, isAdmin, signIn, signOut } = useAuth();

  return (
    <header className="h-16 bg-[#070b14]/90 backdrop-blur-md border-b border-cyan-950/60 sticky top-0 z-40 px-4 lg:px-6 flex items-center justify-between">
      {/* Brand & SOC Telemetry */}
      <div className="flex items-center gap-3">
        <div className="relative flex items-center justify-center w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-500/20 to-blue-600/30 border border-cyan-500/40 text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.25)]">
          <Shield className="w-6 h-6 text-cyan-400" />
          <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-500"></span>
          </span>
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="text-lg font-bold tracking-tight text-white font-mono">
              PHISH<span className="text-cyan-400">GUARD</span>
              <span className="ml-1 text-xs px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                AI SOC
              </span>
            </span>
          </div>
          <div className="flex items-center gap-2 text-[11px] text-slate-400">
            <span className="flex items-center gap-1 text-emerald-400 font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              ENGINE ONLINE
            </span>
            <span className="text-slate-600">|</span>
            <span className="font-mono text-slate-400">MODEL: GEMINI-3.8-FLASH</span>
          </div>
        </div>
      </div>

      {/* Center live badge */}
      <div className="hidden md:flex items-center gap-3 px-3 py-1.5 rounded-full bg-slate-900/80 border border-slate-800 text-xs">
        <Activity className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
        <span className="text-slate-300">Global Threat Monitor:</span>
        <span className="text-amber-400 font-mono font-semibold flex items-center gap-1">
          <ShieldAlert className="w-3.5 h-3.5" />
          {activeIncidentsCount} High-Risk Threats Flagged
        </span>
      </div>

      {/* Right Actions: AI Analyst Button, User Profile */}
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenChat}
          className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 text-xs font-medium transition-all shadow-[0_0_12px_rgba(6,182,212,0.15)] active:scale-95"
          title="Open Gemini Cybersecurity Analyst"
        >
          <Bot className="w-4 h-4 text-cyan-400" />
          <span className="hidden sm:inline">PhishGuard Analyst</span>
          <span className="px-1 py-0.2 bg-cyan-400 text-slate-950 text-[10px] font-bold rounded font-mono">
            AI
          </span>
        </button>

        {user ? (
          <div className="flex items-center gap-3 pl-2 border-l border-slate-800">
            <div className="text-right hidden sm:block">
              <div className="text-xs font-semibold text-slate-200 truncate max-w-[150px]">
                {profile?.displayName || user.displayName || user.email?.split('@')[0]}
              </div>
              <div className="flex items-center justify-end gap-1">
                <span
                  className={`text-[10px] font-mono px-1.5 py-0.2 rounded font-bold ${
                    isAdmin
                      ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                      : role === 'SECURITY_ANALYST'
                      ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                      : 'bg-slate-700/40 text-slate-300'
                  }`}
                >
                  {role}
                </span>
              </div>
            </div>
            <button
              onClick={signOut}
              className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-red-400 hover:border-red-900/50 transition-colors"
              title="Sign out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <button
            onClick={signIn}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-lg shadow-blue-600/20 transition-all"
          >
            <LogIn className="w-3.5 h-3.5" />
            Sign In with Google
          </button>
        )}
      </div>
    </header>
  );
};
